# KYRO AI Android Project Quickstart

1. Open Android Studio (Ladybug / Koala).
2. Select "Open" and choose this unzipped folder.
3. Sync Gradle and run on device or emulator.
4. No client-side Gemini API keys required (handled via backend proxy).
