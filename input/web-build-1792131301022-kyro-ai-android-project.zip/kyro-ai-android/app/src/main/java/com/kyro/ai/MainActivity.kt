package com.kyro.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.kyro.ai.ui.components.KyroBottomBar
import com.kyro.ai.ui.components.KyroHeader
import com.kyro.ai.ui.navigation.Screen
import com.kyro.ai.ui.screens.chat.ChatScreen
import com.kyro.ai.ui.screens.code.CodeScreen
import com.kyro.ai.ui.screens.study.StudyScreen
import com.kyro.ai.ui.screens.studio.StudioScreen
import com.kyro.ai.ui.screens.translator.TranslatorScreen
import com.kyro.ai.ui.screens.writing.WritingScreen
import com.kyro.ai.ui.theme.DarkBackground
import com.kyro.ai.ui.theme.KyroAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KyroAppTheme {
                KyroMainScreen()
            }
        }
    }
}

@Composable
fun KyroMainScreen() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Chat) }

    Scaffold(
        topBar = {
            KyroHeader(
                title = "KYRO AI",
                subtitle = currentScreen.title
            )
        },
        bottomBar = {
            KyroBottomBar(
                currentRoute = currentScreen.route,
                onNavigate = { currentScreen = it }
            )
        },
        containerColor = DarkBackground
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DarkBackground)
        ) {
            when (currentScreen) {
                is Screen.Chat -> ChatScreen()
                is Screen.Study -> StudyScreen()
                is Screen.Writing -> WritingScreen()
                is Screen.Code -> CodeScreen()
                is Screen.Translator -> TranslatorScreen()
                is Screen.Studio -> StudioScreen()
            }
        }
    }
}