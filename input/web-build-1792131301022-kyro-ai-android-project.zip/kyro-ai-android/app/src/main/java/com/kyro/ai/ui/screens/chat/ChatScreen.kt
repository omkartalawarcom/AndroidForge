package com.kyro.ai.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyro.ai.data.model.ChatMessage
import com.kyro.ai.data.model.ChatMessagePayload
import com.kyro.ai.data.repository.KyroRepository
import com.kyro.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    repository: KyroRepository = remember { KyroRepository() }
) {
    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                role = "model",
                text = "Hello! I am KYRO AI. How can I assist your workflow, calculations, or inquiries today?"
            )
        )
    }

    fun sendMessage(text: String) {
        if (text.isBlank() || isLoading) return
        val userMsg = ChatMessage(role = "user", text = text)
        messages.add(userMsg)
        inputText = ""
        isLoading = true

        scope.launch {
            listState.animateScrollToItem(messages.size - 1)
            val history = messages.map { ChatMessagePayload(it.role, it.text) }
            val result = repository.chat(history)
            result.onSuccess { reply ->
                messages.add(ChatMessage(role = "model", text = reply))
            }.onFailure { err ->
                messages.add(ChatMessage(role = "model", text = "Error: " + err.localizedMessage))
            }
            isLoading = false
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 280.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isUser) Brush.horizontalGradient(listOf(NeonPurpleDark, NeonPurplePrimary))
                                else Brush.horizontalGradient(listOf(DarkSurfaceVariant, DarkCardBackground))
                            )
                            .border(1.dp, if (isUser) NeonPurpleLight.copy(alpha = 0.5f) else DarkBorder, RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(text = msg.text, color = if (isUser) Color.White else TextPrimary, fontSize = 14.sp)
                    }
                }
            }
        }

        // Input
        Surface(color = DarkSurface, modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Ask KYRO AI...", color = TextMuted) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = { sendMessage(inputText) }) {
                    Icon(imageVector = Icons.Default.ArrowUpward, contentDescription = "Send", tint = NeonPurpleLight)
                }
            }
        }
    }
}