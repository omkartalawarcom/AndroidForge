package com.kyro.ai.data.api

import com.kyro.ai.data.model.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface KyroApiService {
    @POST("api/ai/chat")
    suspend fun sendChatMessage(@Body request: ChatRequest): ChatResponse

    @POST("api/ai/study")
    suspend fun getStudyAssistance(@Body request: StudyRequest): StudyResponse

    @POST("api/ai/writing")
    suspend fun getWritingAssistance(@Body request: WritingRequest): WritingResponse

    @POST("api/ai/code")
    suspend fun getCodeAssistance(@Body request: CodeRequest): CodeResponse

    @POST("api/ai/translate")
    suspend fun translateText(@Body request: TranslateRequest): TranslateResponse

    @POST("api/ai/studio")
    suspend fun executeStudioPrompt(@Body request: StudioRequest): StudioResponse
}

object ApiClient {
    private var baseUrl: String = "https://your-kyro-backend.run.app/"

    fun setBaseUrl(newUrl: String) {
        baseUrl = if (newUrl.endsWith("/")) newUrl else "$newUrl/"
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    val apiService: KyroApiService by lazy {
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(KyroApiService::class.java)
    }
}