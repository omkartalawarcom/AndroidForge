# KYRO AI - Native Android Application

Native Android app built with **Kotlin** and **Jetpack Compose** featuring a **premium purple neon theme**, matching the KYRO AI aesthetic.

### Features
1. **AI Chat**
2. **Study Assistant**
3. **Writing Assistant**
4. **Code Assistant**
5. **Translator**
6. **AI Studio**

### Zero Client-Side Secret Exposure
The Android app communicates with your server-side API proxy, ensuring the Gemini API key is never bundled in the APK.