import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Helper to get or instantiate Gemini SDK
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey.trim() === '' || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Robust multi-model chain for free-tier supported Gemini models
async function generateContentSafe(
  ai: GoogleGenAI,
  params: {
    contents: any;
    config?: {
      systemInstruction?: string;
      temperature?: number;
      [key: string]: any;
    };
  }
) {
  // Prioritize gemini-3.1-flash-lite for instant response (<1s) and high availability
  const modelsToTry = ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];
  let lastError: any = null;

  for (const model of modelsToTry) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: params.contents,
        config: params.config,
      });
      return { response, modelUsed: model };
    } catch (err: any) {
      lastError = err;
      const msg = err?.message || '';
      // If temporary 503 unavailable, 429 quota, or high demand, try next model silently
      if (msg.includes('503') || msg.includes('UNAVAILABLE') || msg.includes('high demand') || msg.includes('429')) {
        continue;
      }
      throw err;
    }
  }

  throw lastError;
}

// 1. Status & Health Check
app.get('/api/status', (req: Request, res: Response) => {
  const hasApiKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  res.json({
    status: 'online',
    appName: 'KYRO AI',
    hasApiKey,
    defaultModel: 'gemini-3.1-flash-lite',
    supportedFeatures: ['chat', 'study', 'writing', 'coding', 'translator', 'image-prompt'],
  });
});

// System Prompts for Different Assistants
const SYSTEM_PROMPTS = {
  general: `You are KYRO AI, a futuristic, highly intelligent, and helpful AI assistant with deep multi-domain knowledge.
Respond with clarity, warmth, and precision. Use clean Markdown formatting (headings, bullet points, bold key terms, and code blocks) to ensure high readability.`,

  study: `You are KYRO Study Assistant, an empathetic master educator and academic tutor.
Your mission is to make any subject intuitive, engaging, and easy to master.
When explaining concepts:
1. Provide a crystal-clear, intuitive overview with a real-world analogy.
2. Break the concept down into numbered, step-by-step milestones.
3. Highlight key terms and definitions.
4. Conclude with a quick summary and 2-3 interactive reflection questions to test comprehension.`,

  writing: `You are KYRO Writing Studio, an elite author, copywriter, and editorial stylist.
Help users draft essays, professional correspondence, creative fiction, scripts, and articles.
When requested to rewrite or fix grammar:
- Provide the polished version first in full.
- Highlight specific stylistic, grammatical, or tonal enhancements made.
- Adapt tone seamlessly (e.g., academic, persuasive, casual, executive).`,

  coding: `You are KYRO Code Architect, a senior polyglot software engineer and debugger.
When helping with code:
1. Diagnose any bugs, syntax errors, or logical issues with exact line explanations.
2. Provide the corrected, clean, and production-ready code inside standard syntax-highlighted code blocks (\`\`\`language ... \`\`\`).
3. Explain why the fix works and suggest performance or clean-code improvements.
Support all major languages: Python, JavaScript, TypeScript, Java, C++, C#, Go, Rust, SQL, HTML/CSS, etc.`,

  translator: `You are KYRO Multilingual Engine, an expert linguistic and translation specialist.
You specialize in translations across world languages, with exceptional mastery in Kannada (ಕನ್ನಡ) and English.
When translating:
1. Provide the accurate, natural Translation in the target language.
2. If the target language is not Latin-based (e.g., Kannada, Hindi, Japanese), provide the Pronunciation / Roman Transliteration guide.
3. Provide a brief breakdown of vocabulary, grammar context, or cultural nuances.
4. Ensure formal and informal variations are noted if applicable.`,

  image: `You are KYRO Vision & Prompt Architect, a world-class prompt engineer for generative AI image models (Imagen 3, Midjourney v6, Stable Diffusion XL).
When user asks to craft an image idea:
1. Transform their idea into an ultra-detailed, evocative Master Prompt with lighting, texture, camera lens (e.g. 85mm f/1.4, anamorphic), mood, and composition.
2. Provide a Negative Prompt to avoid common defects.
3. Recommend optimal Aspect Ratio and Style Keywords.`,
};

// 2. Chat / Completion API Endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(400).json({
        error: 'GEMINI_API_KEY is not configured on the server.',
        code: 'MISSING_API_KEY',
        advice: 'To enable real AI responses, configure GEMINI_API_KEY in your environment or Secrets panel in AI Studio.',
      });
      return;
    }

    const { messages, mode = 'general', customInstruction, temperature } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Messages array is required.' });
      return;
    }

    const baseSystemPrompt = SYSTEM_PROMPTS[mode as keyof typeof SYSTEM_PROMPTS] || SYSTEM_PROMPTS.general;
    const systemInstruction = customInstruction ? `${baseSystemPrompt}\n\nAdditional instructions: ${customInstruction}` : baseSystemPrompt;

    // Convert message history to Gemini SDK format
    // Gemini SDK expects contents array or chat structure
    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    const { response, modelUsed } = await generateContentSafe(ai, {
      contents,
      config: {
        systemInstruction,
        temperature: typeof temperature === 'number' ? temperature : 0.7,
      },
    });

    const replyText = response.text || '';

    res.json({
      text: replyText,
      model: modelUsed,
      role: 'assistant',
    });
  } catch (err: unknown) {
    console.error('Gemini API error in /api/chat:', err);
    const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
    
    // Check for rate limit or quota exceeded
    const isQuotaError = errorMessage.includes('RESOURCE_EXHAUSTED') || errorMessage.includes('429');
    const isAuthError = errorMessage.includes('API_KEY_INVALID') || errorMessage.includes('UNAUTHENTICATED');

    res.status(500).json({
      error: isQuotaError
        ? 'Gemini API rate limit reached. Please wait a few seconds and try again.'
        : isAuthError
        ? 'Invalid GEMINI_API_KEY. Please verify your API key.'
        : `AI request failed: ${errorMessage}`,
      code: isQuotaError ? 'RATE_LIMIT' : isAuthError ? 'AUTH_ERROR' : 'API_ERROR',
    });
  }
});

// 3. Specialized Study Generator Endpoint (structured study guides & interactive quizzes)
app.post('/api/study/generate', async (req: Request, res: Response) => {
  try {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(400).json({
        error: 'GEMINI_API_KEY is not configured on the server.',
        code: 'MISSING_API_KEY',
      });
      return;
    }

    const { subject, topic, studyMode, difficulty, notes } = req.body;

    let prompt = `Subject: ${subject || 'General'}\nTopic: ${topic || 'Core concepts'}\nDifficulty: ${difficulty || 'College'}\nMode: ${studyMode || 'concept'}\n`;
    if (notes) {
      prompt += `User's Notes / Text:\n"""\n${notes}\n"""\n`;
    }

    let instruction = SYSTEM_PROMPTS.study;
    if (studyMode === 'quiz') {
      prompt += `\nPlease generate an interactive 4-question multiple-choice quiz based on this topic. Format with clear Questions, Options (A, B, C, D), the Correct Answer, and a concise explanation for why it is correct.`;
    } else if (studyMode === 'flashcards') {
      prompt += `\nPlease generate 5 comprehensive flashcards with Front (Question / Concept) and Back (Key Definition / Principle / Formula).`;
    }

    const { response, modelUsed } = await generateContentSafe(ai, {
      contents: prompt,
      config: {
        systemInstruction: instruction,
        temperature: 0.6,
      },
    });

    res.json({
      result: response.text || '',
      model: modelUsed,
    });
  } catch (err: unknown) {
    console.error('Study API error:', err);
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: errorMessage });
  }
});

// 4. Specialized Translation Endpoint (with explicit Kannada & English transliteration)
app.post('/api/translate', async (req: Request, res: Response) => {
  try {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(400).json({
        error: 'GEMINI_API_KEY is not configured on the server.',
        code: 'MISSING_API_KEY',
      });
      return;
    }

    const { text, sourceLang = 'auto', targetLang = 'Kannada' } = req.body;

    if (!text || text.trim() === '') {
      res.status(400).json({ error: 'Text to translate is required.' });
      return;
    }

    const prompt = `Translate the following text from ${sourceLang === 'auto' ? 'detected source language' : sourceLang} to ${targetLang}:
"""
${text}
"""

Provide the output formatted neatly in Markdown with:
1. **Translation**: The direct, high-quality, natural translation in ${targetLang}.
2. **Pronunciation / Transliteration**: (If target language uses non-Latin script, such as Kannada ಕನ್ನಡ, Hindi, etc., provide the romanized phonetics so anyone can read it aloud).
3. **Key Vocabulary & Nuances**: Break down 2-3 important words or idiomatic nuances.
4. **Alternative Contexts**: E.g. Formal vs Casual if applicable.`;

    const { response } = await generateContentSafe(ai, {
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_PROMPTS.translator,
        temperature: 0.3, // Lower temperature for precision
      },
    });

    res.json({
      translatedText: response.text || '',
      sourceLang,
      targetLang,
    });
  } catch (err: unknown) {
    console.error('Translate API error:', err);
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: errorMessage });
  }
});

// 5. Image Studio Endpoint
// As instructed: "If image generation requires a separate API, clearly explain the limitation. Never pretend an image was generated if it was not."
app.post('/api/image-studio', async (req: Request, res: Response) => {
  try {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(400).json({
        error: 'GEMINI_API_KEY is not configured on the server.',
        code: 'MISSING_API_KEY',
      });
      return;
    }

    const { prompt, style = 'Cyberpunk Neon', lighting = 'Neon Purple Rim Light', perspective = 'Cinematic Wide Angle', aspectRatio = '1:1', action = 'enhance' } = req.body;

    if (!prompt || prompt.trim() === '') {
      res.status(400).json({ error: 'Prompt is required.' });
      return;
    }

    if (action === 'generate') {
      // In the Gemini API, image generation models like gemini-3.1-flash-lite-image require a paid billing account.
      // We test if the user has an active billing account / paid model access.
      try {
        const imageGenResponse = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite-image',
          contents: {
            parts: [{ text: `${prompt}, style: ${style}, lighting: ${lighting}, ${perspective}` }],
          },
          config: {
            imageConfig: {
              aspectRatio: aspectRatio as '1:1' | '3:4' | '4:3' | '9:16' | '16:9',
            },
          },
        });

        let generatedImageBase64: string | null = null;
        for (const candidate of imageGenResponse.candidates || []) {
          for (const part of candidate.content?.parts || []) {
            if (part.inlineData?.data) {
              generatedImageBase64 = `data:image/png;base64,${part.inlineData.data}`;
              break;
            }
          }
          if (generatedImageBase64) break;
        }

        if (generatedImageBase64) {
          res.json({
            success: true,
            imageUrl: generatedImageBase64,
            prompt,
          });
          return;
        } else {
          res.json({
            success: false,
            imageUrl: null,
            limitationNotice: 'The model returned a response without image data. Note that Gemini native image generation requires paid tier API access.',
          });
          return;
        }
      } catch (genErr: unknown) {
        const errorMsg = genErr instanceof Error ? genErr.message : 'API error';
        // Honest explanation: never pretend image was generated!
        res.json({
          success: false,
          imageUrl: null,
          limitationNotice: `Image generation requires a Google Cloud billing account with a paid Gemini API key (${errorMsg.includes('quota') || errorMsg.includes('permission') || errorMsg.includes('BILLING') ? 'Billing or quota limit' : 'Model access limitation'}). KYRO AI provides the complete enhanced prompt below ready for Midjourney, DALL-E, Imagen 3, or Stable Diffusion.`,
        });
        return;
      }
    }

    // Default action: Craft ultra-detailed master prompt using gemini-3.8-flash (free tier supported!)
    const promptEngineeringTask = `User Idea: "${prompt}"
Style Selected: ${style}
Lighting: ${lighting}
Perspective: ${perspective}
Aspect Ratio: ${aspectRatio}

Please generate an expert generative AI prompt package:
1. **Master Prompt**: Detailed, highly descriptive prompt with textures, materials, atmospheric depth, lighting, and cinematic optics.
2. **Negative Prompt**: Flaws and unwanted artifacts to eliminate.
3. **Technical Tags & Parameters**: Aspect ratio (--ar ${aspectRatio}), style keywords, render engine parameters.
4. **Artistic Direction Note**: Why this composition works well.`;

    const { response } = await generateContentSafe(ai, {
      contents: promptEngineeringTask,
      config: {
        systemInstruction: SYSTEM_PROMPTS.image,
        temperature: 0.8,
      },
    });

    res.json({
      success: true,
      masterPrompt: response.text || '',
      aspectRatio,
      style,
      lighting,
    });
  } catch (err: unknown) {
    console.error('Image Studio API error:', err);
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: errorMessage });
  }
});

// Serve frontend in production or mount Vite middleware in development
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[KYRO AI Server] running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start KYRO AI server:', err);
});
