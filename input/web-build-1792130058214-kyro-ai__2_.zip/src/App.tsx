import React, { useState, useEffect } from 'react';
import { ActiveTab, ChatMessage, ApiStatus } from './types';
import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { ChatAssistant } from './components/ChatAssistant';
import { StudyAssistant } from './components/StudyAssistant';
import { WritingAssistant } from './components/WritingAssistant';
import { CodingAssistant } from './components/CodingAssistant';
import { TranslatorAssistant } from './components/TranslatorAssistant';
import { ImageStudio } from './components/ImageStudio';
import { ApiKeyModal } from './components/ApiKeyModal';
import { OfflineIndicator } from './components/OfflineIndicator';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('kyro_ai_chat_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [apiStatus, setApiStatus] = useState<ApiStatus | null>(null);
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [lastUserPrompt, setLastUserPrompt] = useState<string>('');

  // Save chat messages to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('kyro_ai_chat_history', JSON.stringify(messages));
    } catch (e) {
      console.error('Failed to save chat to local storage', e);
    }
  }, [messages]);

  // Check API health and key status
  const checkStatus = async () => {
    try {
      const res = await fetch('/api/status');
      if (res.ok) {
        const data: ApiStatus = await res.json();
        setApiStatus(data);
      }
    } catch (e) {
      console.warn('Backend status check error:', e);
    }
  };

  useEffect(() => {
    checkStatus();
  }, []);

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    setLastUserPrompt(text);
    setError(null);

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
      mode: activeTab,
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
          mode: 'general',
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        if (data.code === 'MISSING_API_KEY') {
          setIsKeyModalOpen(true);
        }
        throw new Error(data.error || 'Failed to get AI response');
      }

      const botMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.text,
        timestamp: Date.now(),
        mode: activeTab,
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Something went wrong';
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetry = () => {
    if (lastUserPrompt) {
      handleSendMessage(lastUserPrompt);
    }
  };

  const handleClearChat = () => {
    setMessages([]);
    setError(null);
    try {
      localStorage.removeItem('kyro_ai_chat_history');
    } catch {}
  };

  return (
    <div className="min-h-screen bg-[#090514] text-slate-100 flex flex-col font-sans selection:bg-purple-600/30 selection:text-purple-200">
      <OfflineIndicator />

      {/* Top Bar Header */}
      <Header
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        status={apiStatus}
        onOpenKeyModal={() => setIsKeyModalOpen(true)}
        onNewChat={handleClearChat}
      />

      {/* Main View Area */}
      <main className="flex-1 w-full">
        {activeTab === 'chat' && (
          <ChatAssistant
            messages={messages}
            onSendMessage={handleSendMessage}
            onClearHistory={handleClearChat}
            isLoading={isLoading}
            status={apiStatus}
            onOpenKeyModal={() => setIsKeyModalOpen(true)}
            error={error}
            onRetry={handleRetry}
          />
        )}

        {activeTab === 'study' && <StudyAssistant />}

        {activeTab === 'writing' && <WritingAssistant />}

        {activeTab === 'coding' && <CodingAssistant />}

        {activeTab === 'translator' && <TranslatorAssistant />}

        {activeTab === 'image' && <ImageStudio />}
      </main>

      {/* Mobile Bottom Navigation Bar (Android & Mobile screens) */}
      <MobileBottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Key Setup / Status Guide Modal */}
      <ApiKeyModal
        isOpen={isKeyModalOpen}
        onClose={() => setIsKeyModalOpen(false)}
        status={apiStatus}
      />
    </div>
  );
}
