export type ActiveTab = 'chat' | 'study' | 'writing' | 'coding' | 'translator' | 'image';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  mode?: ActiveTab;
}

export interface ApiStatus {
  status: string;
  appName: string;
  hasApiKey: boolean;
  defaultModel: string;
  supportedFeatures: string[];
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}
