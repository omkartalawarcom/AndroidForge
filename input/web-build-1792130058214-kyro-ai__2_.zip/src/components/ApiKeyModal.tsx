import React from 'react';
import { X, Key, ShieldCheck, CheckCircle2, AlertTriangle, ExternalLink } from 'lucide-react';
import { ApiStatus } from '../types';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: ApiStatus | null;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ isOpen, onClose, status }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="w-full max-w-lg rounded-2xl bg-[#120826] border border-purple-500/40 p-6 shadow-2xl text-slate-100 relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-purple-900/40 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 pb-4 border-b border-purple-900/40">
          <div className="p-2.5 rounded-xl bg-purple-950/80 border border-purple-500/30 text-purple-400">
            <Key className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              Gemini API Key Configuration
            </h2>
            <p className="text-xs text-purple-300/80">
              KYRO AI runs server-side with zero client exposure
            </p>
          </div>
        </div>

        {/* Current Status Indicator */}
        <div className="mt-4 p-3.5 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {status?.hasApiKey ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            )}
            <div>
              <p className="text-xs font-semibold text-white">
                {status?.hasApiKey ? 'Server API Key Configured' : 'API Key Pending in Server'}
              </p>
              <p className="text-[11px] text-slate-400">
                Model: <span className="text-purple-300 font-mono">{status?.defaultModel || 'gemini-3.1-flash-lite'}</span> (Free Tier)
              </p>
            </div>
          </div>
          <span
            className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border ${
              status?.hasApiKey
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/30'
                : 'bg-amber-950/60 text-amber-300 border-amber-500/30'
            }`}
          >
            {status?.hasApiKey ? 'Ready' : 'Setup Required'}
          </span>
        </div>

        {/* Step by step guide */}
        <div className="mt-5 space-y-3 text-xs text-slate-300">
          <h3 className="text-xs font-bold uppercase tracking-wider text-purple-400">
            How to configure securely
          </h3>

          <div className="space-y-2.5">
            <div className="p-3 rounded-xl bg-[#190d33] border border-purple-900/40">
              <p className="font-semibold text-purple-200">1. Get your free Gemini API Key</p>
              <p className="text-slate-400 mt-1">
                Obtain a free Google Gemini API key from Google AI Studio. No credit card required.
              </p>
              <a
                href="https://aistudio.google.com/app/apikey"
                target="_blank"
                rel="noreferrer"
                className="mt-2 inline-flex items-center gap-1.5 text-xs text-purple-300 hover:text-purple-100 underline decoration-purple-400"
              >
                <span>Open Google AI Studio Key Manager</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="p-3 rounded-xl bg-[#190d33] border border-purple-900/40">
              <p className="font-semibold text-purple-200">2. Configure Server Environment</p>
              <p className="text-slate-400 mt-1">
                Add your key to the project root <code className="text-purple-300 font-mono bg-purple-950 px-1 py-0.5 rounded">.env</code> file or the <strong>Settings &gt; Secrets</strong> panel in Google AI Studio:
              </p>
              <pre className="mt-2 p-2 bg-[#0a0417] rounded-lg font-mono text-[11px] text-purple-300 overflow-x-auto border border-purple-900/50">
GEMINI_API_KEY="AIzaSyYourGeminiApiKeyHere"
              </pre>
            </div>

            <div className="p-3 rounded-xl bg-[#190d33] border border-purple-900/40 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white">Full Security Guarantee</p>
                <p className="text-slate-400 mt-0.5">
                  Your key is read exclusively on the Node server and never sent to frontend browser JavaScript. All requests to Gemini route through secure backend proxy endpoints.
                </p>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-6 w-full rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 py-2.5 text-xs font-semibold text-white shadow-lg shadow-purple-600/30 transition-all"
        >
          Close Guide
        </button>
      </div>
    </div>
  );
};
