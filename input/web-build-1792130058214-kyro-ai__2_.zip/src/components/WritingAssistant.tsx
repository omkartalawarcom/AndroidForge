import React, { useState } from 'react';
import { MarkdownRenderer } from './MarkdownRenderer';
import { PenTool, Sparkles, Copy, Check, Wand2, RefreshCw } from 'lucide-react';

export const WritingAssistant: React.FC = () => {
  const [taskType, setTaskType] = useState('essay');
  const [tone, setTone] = useState('Professional');
  const [length, setLength] = useState('Balanced');
  const [promptInput, setPromptInput] = useState('');
  const [referenceText, setReferenceText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const taskOptions = [
    { id: 'essay', label: 'Structured Essay' },
    { id: 'letter', label: 'Professional Letter / Email' },
    { id: 'story', label: 'Creative Fiction & Story' },
    { id: 'rewrite', label: 'Rewrite & Polish Tone' },
    { id: 'grammar', label: 'Grammar & Syntax Fixer' },
    { id: 'summarize', label: 'Text Summarizer' },
  ];

  const tones = ['Professional', 'Academic', 'Persuasive', 'Casual', 'Futuristic', 'Narrative'];
  const lengths = ['Concise', 'Balanced', 'Comprehensive'];

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim() && !referenceText.trim()) return;

    setIsLoading(true);
    setError(null);

    let instruction = `You are KYRO Writing Studio.
Task: ${taskType.toUpperCase()}
Tone: ${tone}
Target Length: ${length}

User Input:
${promptInput ? `Prompt / Topic: "${promptInput}"\n` : ''}
${referenceText ? `Source Text:\n"""\n${referenceText}\n"""\n` : ''}

Please draft or refine the text to world-class standards.`;

    if (taskType === 'grammar') {
      instruction += `\nFix all grammatical, spelling, typographical, and structural errors. Provide:
1. The Clean Corrected Text
2. A bulleted list of Corrections Made and Why.`;
    } else if (taskType === 'rewrite') {
      instruction += `\nRewrite the text in the chosen ${tone} tone with enhanced eloquence, clarity, and vocabulary.`;
    }

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'writing',
          messages: [{ role: 'user', content: instruction }],
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to process writing task');
      }

      setResult(data.text);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error processing writing request';
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const copyResult = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const wordCount = result ? result.trim().split(/\s+/).length : 0;
  const readTimeMinutes = Math.max(1, Math.ceil(wordCount / 200));

  return (
    <div className="max-w-6xl mx-auto w-full px-3 sm:px-6 py-6 pb-24 lg:pb-12">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2.5 text-purple-400 text-xs font-semibold uppercase tracking-wider mb-1">
          <PenTool className="w-4 h-4" />
          <span>Writing &amp; Editorial Studio</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">
          KYRO Writing Assistant
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
          Craft essays, executive emails, creative narratives, or polish grammar and rewrite existing text with high stylistic control.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Form Controls */}
        <div className="lg:col-span-5 bg-[#120827] rounded-2xl border border-purple-900/40 p-4 sm:p-5 shadow-xl space-y-4">
          <form onSubmit={handleGenerate} className="space-y-4">
            {/* Task Type */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Writing Format
              </label>
              <div className="grid grid-cols-2 gap-2">
                {taskOptions.map((task) => (
                  <button
                    key={task.id}
                    type="button"
                    onClick={() => setTaskType(task.id)}
                    className={`p-2.5 rounded-xl text-xs font-medium transition-all text-left truncate ${
                      taskType === task.id
                        ? 'bg-purple-600 text-white shadow-sm shadow-purple-600/30 font-semibold'
                        : 'bg-purple-950/30 text-slate-400 border border-purple-900/40 hover:text-purple-200'
                    }`}
                  >
                    {task.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Tone Selector */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Tone &amp; Voice
              </label>
              <div className="flex flex-wrap gap-1.5">
                {tones.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTone(t)}
                    className={`px-2.5 py-1 rounded-lg text-xs transition-all ${
                      tone === t
                        ? 'bg-purple-900/80 text-purple-200 border border-purple-500/50 font-semibold'
                        : 'bg-purple-950/30 text-slate-400 border border-purple-900/30 hover:text-purple-200'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Length Selector */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Length
              </label>
              <div className="flex gap-2">
                {lengths.map((len) => (
                  <button
                    key={len}
                    type="button"
                    onClick={() => setLength(len)}
                    className={`flex-1 py-1 rounded-lg text-xs transition-all ${
                      length === len
                        ? 'bg-purple-900/80 text-purple-200 border border-purple-500/50 font-semibold'
                        : 'bg-purple-950/30 text-slate-400 border border-purple-900/30 hover:text-purple-200'
                    }`}
                  >
                    {len}
                  </button>
                ))}
              </div>
            </div>

            {/* Topic / Prompt */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Instructions or Topic
              </label>
              <input
                type="text"
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                placeholder="e.g. Write an introduction on AI ethics in healthcare"
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 px-3 py-2 text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-purple-400 transition-all"
              />
            </div>

            {/* Source Text for Rewrite/Grammar/Summarize */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5 flex items-center justify-between">
                <span>Source Text to Polish / Rewrite / Fix</span>
                <span className="text-[10px] text-slate-400 font-normal">Optional if writing from prompt</span>
              </label>
              <textarea
                value={referenceText}
                onChange={(e) => setReferenceText(e.target.value)}
                placeholder="Paste the draft, letter, or notes you want KYRO to improve..."
                rows={4}
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 p-3 text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-purple-400 transition-all resize-y"
              />
            </div>

            <button
              type="submit"
              disabled={(!promptInput.trim() && !referenceText.trim()) || isLoading}
              className="w-full rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs py-2.5 shadow-lg shadow-purple-600/30 transition-all disabled:opacity-40 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-purple-200" />
                  <span>Drafting Text...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  <span>Compose / Refine</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Output Area */}
        <div className="lg:col-span-7 bg-[#120827] rounded-2xl border border-purple-900/40 p-5 shadow-xl min-h-[420px] flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-4">
            <div className="flex items-center gap-2 text-xs text-purple-300 font-semibold">
              <PenTool className="w-4 h-4 text-purple-400" />
              <span>Composition Canvas</span>
              {result && (
                <span className="text-[10px] text-slate-400 font-normal">
                  ({wordCount} words · ~{readTimeMinutes} min read)
                </span>
              )}
            </div>

            {result && (
              <button
                onClick={copyResult}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 text-xs text-purple-300 hover:text-white border border-purple-800/40 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Text'}</span>
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 space-y-3">
                <div className="w-12 h-12 rounded-xl bg-purple-950/60 border border-purple-500/40 flex items-center justify-center animate-pulse">
                  <Sparkles className="w-6 h-6 text-purple-400" />
                </div>
                <p className="text-xs text-purple-300 font-medium">
                  KYRO Writing Studio is sculpting your prose...
                </p>
              </div>
            ) : error ? (
              <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs">
                {error}
              </div>
            ) : result ? (
              <div className="space-y-4">
                <MarkdownRenderer content={result} />
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 text-slate-400 space-y-2">
                <PenTool className="w-10 h-10 text-purple-500/40" />
                <p className="text-xs">
                  Choose a format, set your tone, and enter your topic or source draft to generate refined prose.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
