import React, { useState } from 'react';
import { MarkdownRenderer } from './MarkdownRenderer';
import { GraduationCap, BookOpen, Brain, Sparkles, Copy, Check, FileText, HelpCircle, Layers } from 'lucide-react';

export const StudyAssistant: React.FC = () => {
  const [subject, setSubject] = useState('Physics');
  const [topic, setTopic] = useState('');
  const [studyMode, setStudyMode] = useState<'concept' | 'summarize' | 'quiz' | 'flashcards'>('concept');
  const [difficulty, setDifficulty] = useState('College / Undergrad');
  const [notes, setNotes] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const subjects = [
    'Physics',
    'Mathematics',
    'Computer Science',
    'Chemistry',
    'Biology',
    'History',
    'Economics',
    'Literature',
    'Psychology',
  ];

  const handleStudy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim() && !notes.trim()) return;

    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/study/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject,
          topic: topic.trim() || 'Core concepts summary',
          studyMode,
          difficulty,
          notes: notes.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate study guide');
      }

      setResult(data.result);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error generating study material';
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const copyResult = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto w-full px-3 sm:px-6 py-6 pb-24 lg:pb-12">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2.5 text-purple-400 text-xs font-semibold uppercase tracking-wider mb-1">
          <GraduationCap className="w-4 h-4" />
          <span>Academic Copilot</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">
          KYRO Study Assistant
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
          Master any subject with step-by-step concept breakdowns, lecture note summaries, and interactive quizzes powered by Google Gemini.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Form Controls */}
        <div className="lg:col-span-5 bg-[#120827] rounded-2xl border border-purple-900/40 p-4 sm:p-5 shadow-xl space-y-4">
          <form onSubmit={handleStudy} className="space-y-4">
            {/* Subject Selector */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Subject
              </label>
              <div className="flex flex-wrap gap-1.5">
                {subjects.map((sub) => (
                  <button
                    key={sub}
                    type="button"
                    onClick={() => setSubject(sub)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                      subject === sub
                        ? 'bg-purple-600 text-white shadow-sm shadow-purple-600/30 font-semibold'
                        : 'bg-purple-950/40 text-slate-400 hover:text-purple-200 border border-purple-900/40'
                    }`}
                  >
                    {sub}
                  </button>
                ))}
              </div>
            </div>

            {/* Study Mode */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Study Goal
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'concept', label: 'Step-by-Step Breakdown', icon: Brain },
                  { id: 'summarize', label: 'Summarize Notes', icon: FileText },
                  { id: 'quiz', label: 'Practice Quiz', icon: HelpCircle },
                  { id: 'flashcards', label: 'Flashcard Cards', icon: Layers },
                ].map((mode) => {
                  const Icon = mode.icon;
                  const isActive = studyMode === mode.id;
                  return (
                    <button
                      key={mode.id}
                      type="button"
                      onClick={() => setStudyMode(mode.id as any)}
                      className={`flex items-center gap-2 p-2 rounded-xl text-xs font-medium transition-all text-left ${
                        isActive
                          ? 'bg-purple-900/60 text-white border border-purple-500/50 shadow-sm'
                          : 'bg-purple-950/30 text-slate-400 border border-purple-900/40 hover:text-purple-200'
                      }`}
                    >
                      <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-purple-300' : 'text-slate-400'}`} />
                      <span className="truncate">{mode.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Topic Input */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Topic or Question
              </label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., Photosynthesis light reactions, Eigenvalues, Newton's 2nd Law"
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 px-3 py-2 text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-purple-400 focus:shadow-[0_0_15px_rgba(168,85,247,0.25)] transition-all"
              />
            </div>

            {/* Notes / Textarea */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5 flex items-center justify-between">
                <span>Lecture Notes or Reference Text (Optional)</span>
                <span className="text-[10px] text-slate-400 font-normal">Paste syllabus or textbook excerpt</span>
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Paste class notes, problem statements, or article text to explain or summarize..."
                rows={4}
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 p-3 text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-purple-400 focus:shadow-[0_0_15px_rgba(168,85,247,0.25)] transition-all resize-y"
              />
            </div>

            {/* Difficulty Level */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Academic Level
              </label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value)}
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-purple-400"
              >
                <option value="Middle School">Middle School / Foundational</option>
                <option value="High School">High School (AP / IB)</option>
                <option value="College / Undergrad">College / Undergraduate</option>
                <option value="Graduate / Advanced">Graduate / Expert Researcher</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={(!topic.trim() && !notes.trim()) || isLoading}
              className="w-full rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs py-2.5 shadow-lg shadow-purple-600/30 transition-all disabled:opacity-40 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin text-purple-200" />
                  <span>Synthesizing Study Guide...</span>
                </>
              ) : (
                <>
                  <BookOpen className="w-4 h-4" />
                  <span>Generate Study Material</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Output Display Area */}
        <div className="lg:col-span-7 bg-[#120827] rounded-2xl border border-purple-900/40 p-5 shadow-xl min-h-[420px] flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-4">
            <div className="flex items-center gap-2 text-xs text-purple-300 font-semibold">
              <Brain className="w-4 h-4 text-purple-400" />
              <span>Interactive Study Output</span>
            </div>

            {result && (
              <button
                onClick={copyResult}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 text-xs text-purple-300 hover:text-white border border-purple-800/40 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Guide'}</span>
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 space-y-3">
                <div className="w-12 h-12 rounded-xl bg-purple-950/60 border border-purple-500/40 flex items-center justify-center animate-pulse">
                  <Brain className="w-6 h-6 text-purple-400" />
                </div>
                <p className="text-xs text-purple-300 font-medium">
                  KYRO AI is distilling {subject} concepts step-by-step...
                </p>
              </div>
            ) : error ? (
              <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs">
                {error}
              </div>
            ) : result ? (
              <div className="space-y-4">
                <MarkdownRenderer content={result} />
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 text-slate-400 space-y-2">
                <GraduationCap className="w-10 h-10 text-purple-500/40" />
                <p className="text-xs">
                  Select your subject, enter a topic, or paste lecture notes to generate tailored explanations.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
