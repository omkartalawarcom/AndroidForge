import React from 'react';
import { ActiveTab, ApiStatus } from '../types';
import { PWAInstallButton } from './PWAInstallButton';
import { Sparkles, Key, MessageSquare, GraduationCap, PenTool, Code2, Globe2, Image as ImageIcon } from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  status: ApiStatus | null;
  onOpenKeyModal: () => void;
  onNewChat: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  status,
  onOpenKeyModal,
  onNewChat,
}) => {
  const navItems: { id: ActiveTab; label: string; icon: React.ElementType }[] = [
    { id: 'chat', label: 'AI Chat', icon: MessageSquare },
    { id: 'study', label: 'Study', icon: GraduationCap },
    { id: 'writing', label: 'Writing', icon: PenTool },
    { id: 'coding', label: 'Coding', icon: Code2 },
    { id: 'translator', label: 'Translator', icon: Globe2 },
    { id: 'image', label: 'Image Studio', icon: ImageIcon },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0a0518]/90 backdrop-blur-md border-b border-purple-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-6">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onTabChange('chat')}
            className="flex items-center gap-2.5 text-left group focus:outline-none"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 via-fuchsia-500 to-indigo-500 p-0.5 shadow-lg shadow-purple-600/30 transition-transform group-hover:scale-105">
              <div className="w-full h-full bg-[#0d0722] rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-purple-300 animate-pulse" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-fuchsia-300 to-purple-400 whitespace-nowrap">
                KYRO AI
              </span>
              <span className="text-[10px] font-medium tracking-widest text-purple-400/80 uppercase">
                Neon Intelligence
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Desktop/Tablet) */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-purple-900/50 text-purple-200 border border-purple-500/40 shadow-sm shadow-purple-500/20'
                    : 'text-slate-400 hover:text-purple-200 hover:bg-purple-950/40'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-purple-300' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action & Controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          <PWAInstallButton />

          <button
            onClick={onOpenKeyModal}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-all ${
              status?.hasApiKey
                ? 'border-emerald-500/30 bg-emerald-950/30 text-emerald-300 hover:bg-emerald-950/50'
                : 'border-amber-500/40 bg-amber-950/40 text-amber-300 hover:bg-amber-950/60 animate-pulse'
            }`}
            title="Configure Gemini API Key"
          >
            <Key className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {status?.hasApiKey ? 'API Ready' : 'API Key Setup'}
            </span>
          </button>

          {activeTab === 'chat' && (
            <button
              onClick={onNewChat}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600/80 hover:bg-purple-600 text-white text-xs font-semibold shadow-md shadow-purple-600/20 transition-all active:scale-95 whitespace-nowrap"
            >
              <span>New Chat</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
