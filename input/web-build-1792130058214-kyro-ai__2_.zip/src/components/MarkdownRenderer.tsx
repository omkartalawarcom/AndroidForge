import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  // Simple robust markdown parser to handle code blocks, lists, headers, bold, italics, etc.
  // without heavy external packages
  const parseBlocks = (text: string) => {
    const lines = text.split('\n');
    const blocks: React.ReactNode[] = [];
    let i = 0;

    while (i < lines.length) {
      const line = lines[i];

      // Check for code block ```language
      if (line.trim().startsWith('```')) {
        const lang = line.trim().slice(3).trim() || 'code';
        const codeLines: string[] = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith('```')) {
          codeLines.push(lines[i]);
          i++;
        }
        i++; // skip closing ```
        const codeText = codeLines.join('\n');
        blocks.push(<CodeBlock key={`code-${i}`} language={lang} code={codeText} />);
        continue;
      }

      // Check for headings
      if (line.startsWith('### ')) {
        blocks.push(
          <h3 key={`h3-${i}`} className="text-base font-semibold text-purple-200 mt-4 mb-2">
            {formatInlineText(line.slice(4))}
          </h3>
        );
        i++;
        continue;
      }
      if (line.startsWith('## ')) {
        blocks.push(
          <h2 key={`h2-${i}`} className="text-lg font-bold text-purple-300 mt-5 mb-2.5 pb-1 border-b border-purple-900/40">
            {formatInlineText(line.slice(3))}
          </h2>
        );
        i++;
        continue;
      }
      if (line.startsWith('# ')) {
        blocks.push(
          <h1 key={`h1-${i}`} className="text-xl font-extrabold text-white mt-6 mb-3">
            {formatInlineText(line.slice(2))}
          </h1>
        );
        i++;
        continue;
      }

      // Check for blockquote >
      if (line.startsWith('> ')) {
        blocks.push(
          <blockquote key={`quote-${i}`} className="my-2.5 pl-3 border-l-2 border-purple-500/60 text-purple-200/90 italic bg-purple-950/20 py-1 rounded-r-lg">
            {formatInlineText(line.slice(2))}
          </blockquote>
        );
        i++;
        continue;
      }

      // Bullet points
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const listItems: string[] = [];
        while (i < lines.length && (lines[i].trim().startsWith('- ') || lines[i].trim().startsWith('* '))) {
          listItems.push(lines[i].trim().slice(2));
          i++;
        }
        blocks.push(
          <ul key={`ul-${i}`} className="my-2 space-y-1.5 pl-5 list-disc text-slate-200 marker:text-purple-400">
            {listItems.map((item, idx) => (
              <li key={idx} className="leading-relaxed">
                {formatInlineText(item)}
              </li>
            ))}
          </ul>
        );
        continue;
      }

      // Numbered lists
      if (/^\d+\.\s/.test(line.trim())) {
        const listItems: string[] = [];
        while (i < lines.length && /^\d+\.\s/.test(lines[i].trim())) {
          listItems.push(lines[i].trim().replace(/^\d+\.\s/, ''));
          i++;
        }
        blocks.push(
          <ol key={`ol-${i}`} className="my-2 space-y-1.5 pl-5 list-decimal text-slate-200 marker:text-purple-400">
            {listItems.map((item, idx) => (
              <li key={idx} className="leading-relaxed">
                {formatInlineText(item)}
              </li>
            ))}
          </ol>
        );
        continue;
      }

      // Empty line
      if (line.trim() === '') {
        i++;
        continue;
      }

      // Regular paragraph
      blocks.push(
        <p key={`p-${i}`} className="my-2 leading-relaxed text-slate-200">
          {formatInlineText(line)}
        </p>
      );
      i++;
    }

    return blocks;
  };

  const formatInlineText = (text: string): React.ReactNode => {
    // Process inline code `code`, bold **text**, and italic *text*
    const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);
    return parts.map((part, idx) => {
      if (part.startsWith('`') && part.endsWith('`')) {
        return (
          <code key={idx} className="px-1.5 py-0.5 mx-0.5 rounded bg-purple-950/80 border border-purple-800/50 text-purple-300 font-mono text-xs">
            {part.slice(1, -1)}
          </code>
        );
      }
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={idx} className="font-semibold text-white">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return (
          <em key={idx} className="italic text-purple-200">
            {part.slice(1, -1)}
          </em>
        );
      }
      return part;
    });
  };

  return <div className="text-sm prose-invert max-w-none">{parseBlocks(content)}</div>;
};

const CodeBlock: React.FC<{ language: string; code: string }> = ({ language, code }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="my-3 rounded-xl overflow-hidden border border-purple-500/30 bg-[#0c061d] shadow-lg">
      <div className="flex items-center justify-between px-3.5 py-1.5 bg-[#170a34] border-b border-purple-900/40 text-xs text-purple-300/80">
        <span className="font-mono uppercase tracking-wider text-[11px] font-semibold text-purple-400">
          {language}
        </span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 px-2 py-0.5 rounded hover:bg-purple-900/50 text-slate-300 hover:text-white transition-colors"
          title="Copy code"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          <span className="text-[11px]">{copied ? 'Copied!' : 'Copy'}</span>
        </button>
      </div>
      <div className="p-3.5 overflow-x-auto font-mono text-xs text-purple-100 leading-relaxed">
        <pre><code>{code}</code></pre>
      </div>
    </div>
  );
};
