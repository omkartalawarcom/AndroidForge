import React, { useState } from 'react';
import { MarkdownRenderer } from './MarkdownRenderer';
import { Globe2, ArrowRightLeft, Volume2, Copy, Check, Sparkles, Languages } from 'lucide-react';

export const TranslatorAssistant: React.FC = () => {
  const [sourceLang, setSourceLang] = useState('English');
  const [targetLang, setTargetLang] = useState('Kannada (ಕನ್ನಡ)');
  const [inputText, setInputText] = useState('');
  const [translatedText, setTranslatedText] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const languages = [
    { name: 'Kannada (ಕನ್ನಡ)', code: 'kn', isSpecial: true },
    { name: 'English', code: 'en', isSpecial: true },
    { name: 'Hindi (हिंदी)', code: 'hi' },
    { name: 'Spanish (Español)', code: 'es' },
    { name: 'French (Français)', code: 'fr' },
    { name: 'German (Deutsch)', code: 'de' },
    { name: 'Japanese (日本語)', code: 'ja' },
    { name: 'Tamil (தமிழ்)', code: 'ta' },
    { name: 'Telugu (తెలుగు)', code: 'te' },
    { name: 'Arabic (العربية)', code: 'ar' },
    { name: 'Chinese (中文)', code: 'zh' },
    { name: 'Russian (Русский)', code: 'ru' },
  ];

  const quickSamples = [
    { text: 'Hello, how can I help you today?', source: 'English', target: 'Kannada (ಕನ್ನಡ)' },
    { text: 'ನಮಸ್ಕಾರ, ನೀವು ಹೇಗಿದ್ದೀರಿ?', source: 'Kannada (ಕನ್ನಡ)', target: 'English' },
    { text: 'Artificial Intelligence empowers human creativity.', source: 'English', target: 'Kannada (ಕನ್ನಡ)' },
    { text: 'ಜ್ಞಾನವೇ ನಿಜವಾದ ಶಕ್ತಿ.', source: 'Kannada (ಕನ್ನಡ)', target: 'English' },
  ];

  const handleSwap = () => {
    const prevSource = sourceLang;
    const prevTarget = targetLang;
    setSourceLang(prevTarget);
    setTargetLang(prevSource);
    // If there is translated text, swap text too
    if (translatedText && inputText) {
      // Keep input
      setInputText(inputText);
    }
  };

  const handleTranslate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: inputText.trim(),
          sourceLang,
          targetLang,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to translate');
      }

      setTranslatedText(data.translatedText);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error executing translation';
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const copyResult = () => {
    if (!translatedText) return;
    navigator.clipboard.writeText(translatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const playSpeech = (textToSpeak: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    setIsPlayingAudio(true);

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.rate = 0.9;

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="max-w-6xl mx-auto w-full px-3 sm:px-6 py-6 pb-24 lg:pb-12">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2.5 text-purple-400 text-xs font-semibold uppercase tracking-wider mb-1">
          <Globe2 className="w-4 h-4" />
          <span>Multilingual Engine</span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              KYRO Translator
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Accurate translation between English, Kannada (ಕನ್ನಡ), and world languages with pronunciation guidance.
            </p>
          </div>

          {/* Dedicated Kannada <-> English Quick Switcher */}
          <button
            onClick={() => {
              if (sourceLang === 'English') {
                setSourceLang('Kannada (ಕನ್ನಡ)');
                setTargetLang('English');
              } else {
                setSourceLang('English');
                setTargetLang('Kannada (ಕನ್ನಡ)');
              }
            }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-950/80 border border-purple-500/40 text-purple-200 text-xs font-semibold hover:bg-purple-900/60 shadow-md shadow-purple-900/20 transition-all self-start"
          >
            <Languages className="w-4 h-4 text-purple-400" />
            <span>ಕನ್ನಡ ⇄ English Mode</span>
          </button>
        </div>
      </div>

      {/* Language Bar */}
      <div className="bg-[#120827] rounded-2xl border border-purple-900/40 p-3 sm:p-4 shadow-xl mb-6 flex flex-wrap items-center justify-between gap-3">
        {/* Source Language Picker */}
        <div className="flex items-center gap-2 flex-1 min-w-[140px]">
          <span className="text-xs text-purple-400 font-semibold uppercase">From:</span>
          <select
            value={sourceLang}
            onChange={(e) => setSourceLang(e.target.value)}
            className="flex-1 rounded-xl bg-[#0a0518] border border-purple-900/50 px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-purple-400 font-medium"
          >
            {languages.map((l) => (
              <option key={l.name} value={l.name}>
                {l.name}
              </option>
            ))}
          </select>
        </div>

        {/* Swap Button */}
        <button
          onClick={handleSwap}
          className="p-2 rounded-xl bg-purple-950 hover:bg-purple-900/80 text-purple-300 hover:text-white border border-purple-800/40 shadow-sm transition-transform active:rotate-180"
          title="Swap languages"
        >
          <ArrowRightLeft className="w-4 h-4" />
        </button>

        {/* Target Language Picker */}
        <div className="flex items-center gap-2 flex-1 min-w-[140px]">
          <span className="text-xs text-purple-400 font-semibold uppercase">To:</span>
          <select
            value={targetLang}
            onChange={(e) => setTargetLang(e.target.value)}
            className="flex-1 rounded-xl bg-[#0a0518] border border-purple-900/50 px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-purple-400 font-medium"
          >
            {languages.map((l) => (
              <option key={l.name} value={l.name}>
                {l.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Dual Pane Translation Area */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
        {/* Source Text Input Box */}
        <div className="bg-[#120827] rounded-2xl border border-purple-900/40 p-4 sm:p-5 shadow-xl flex flex-col min-h-[380px]">
          <div className="flex items-center justify-between pb-2.5 border-b border-purple-900/40 mb-3 text-xs text-purple-300 font-medium">
            <span>Input ({sourceLang})</span>
            <span className="text-slate-400">{inputText.length} characters</span>
          </div>

          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={`Enter text in ${sourceLang} to translate...`}
            rows={8}
            className="flex-1 w-full bg-transparent border-0 text-sm sm:text-base text-slate-100 placeholder:text-slate-500 focus:outline-none resize-none leading-relaxed"
          />

          {/* Quick Sample Chips */}
          <div className="pt-3 border-t border-purple-900/30 mt-2">
            <span className="text-[11px] text-purple-400/80 font-medium block mb-1.5">
              Try sample phrases:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {quickSamples.map((sample, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setInputText(sample.text);
                    setSourceLang(sample.source);
                    setTargetLang(sample.target);
                  }}
                  className="px-2 py-1 rounded-lg bg-purple-950/40 hover:bg-purple-900/40 border border-purple-800/30 text-[11px] text-slate-300 hover:text-white transition-colors truncate max-w-[240px]"
                >
                  {sample.text}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between gap-3">
            {inputText && (
              <button
                type="button"
                onClick={() => playSpeech(inputText)}
                disabled={isPlayingAudio}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-purple-300 hover:bg-purple-950/40 transition-colors"
                title="Listen to input"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Listen</span>
              </button>
            )}

            <button
              onClick={handleTranslate}
              disabled={!inputText.trim() || isLoading}
              className="ml-auto rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs px-5 py-2.5 shadow-lg shadow-purple-600/30 transition-all disabled:opacity-40 flex items-center gap-2"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin text-purple-200" />
                  <span>Translating...</span>
                </>
              ) : (
                <>
                  <Languages className="w-4 h-4" />
                  <span>Translate to {targetLang}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Translation Output Box */}
        <div className="bg-[#120827] rounded-2xl border border-purple-900/40 p-4 sm:p-5 shadow-xl flex flex-col min-h-[380px]">
          <div className="flex items-center justify-between pb-2.5 border-b border-purple-900/40 mb-3 text-xs text-purple-300 font-medium">
            <span>Result ({targetLang})</span>
            {translatedText && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => playSpeech(translatedText.split('\n')[0] || '')}
                  className="flex items-center gap-1 text-[11px] text-purple-300 hover:text-white transition-colors"
                  title="Listen to translation"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen</span>
                </button>
                <button
                  onClick={copyResult}
                  className="flex items-center gap-1 text-[11px] text-purple-300 hover:text-white transition-colors"
                  title="Copy translation"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            )}
          </div>

          <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 space-y-3">
                <div className="w-12 h-12 rounded-xl bg-purple-950/60 border border-purple-500/40 flex items-center justify-center animate-pulse">
                  <Globe2 className="w-6 h-6 text-purple-400" />
                </div>
                <p className="text-xs text-purple-300 font-medium">
                  KYRO is translating into {targetLang} with phonetics...
                </p>
              </div>
            ) : error ? (
              <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs">
                {error}
              </div>
            ) : translatedText ? (
              <div className="space-y-4">
                <MarkdownRenderer content={translatedText} />
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 text-slate-400 space-y-2">
                <Globe2 className="w-10 h-10 text-purple-500/40" />
                <p className="text-xs">
                  Your translation and pronunciation guide will appear here.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
