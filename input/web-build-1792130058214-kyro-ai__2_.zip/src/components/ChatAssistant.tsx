import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, ApiStatus } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';
import { Send, Sparkles, Trash2, Bot, User, AlertCircle, RefreshCw, Copy, Check } from 'lucide-react';

interface ChatAssistantProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => Promise<void>;
  onClearHistory: () => void;
  isLoading: boolean;
  status: ApiStatus | null;
  onOpenKeyModal: () => void;
  error: string | null;
  onRetry: () => void;
}

export const ChatAssistant: React.FC<ChatAssistantProps> = ({
  messages,
  onSendMessage,
  onClearHistory,
  isLoading,
  status,
  onOpenKeyModal,
  error,
  onRetry,
}) => {
  const [input, setInput] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const starterPrompts = [
    'Explain how neural networks learn in simple terms',
    'Write a concise executive summary for a project launch',
    'What are the core differences between React and Svelte?',
    'Give me a step-by-step strategy to overcome procrastination',
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    const msg = input.trim();
    setInput('');
    onSendMessage(msg);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const copyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem-4rem)] lg:h-[calc(100vh-4rem)] max-w-5xl mx-auto w-full px-2 sm:px-4">
      {/* Top Banner if API Key is missing */}
      {!status?.hasApiKey && (
        <div className="my-2 p-3 rounded-xl bg-purple-950/50 border border-purple-500/30 flex items-center justify-between text-xs text-purple-200">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
            <span>Connect your free Gemini API key to activate live responses.</span>
          </div>
          <button
            onClick={onOpenKeyModal}
            className="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs whitespace-nowrap"
          >
            Configure
          </button>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 p-0.5 shadow-xl shadow-purple-600/30">
              <div className="w-full h-full bg-[#0e0724] rounded-[14px] flex items-center justify-center">
                <Sparkles className="w-8 h-8 text-purple-300 animate-pulse" />
              </div>
            </div>

            <div className="max-w-md space-y-2">
              <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-fuchsia-200 to-purple-400">
                Welcome to KYRO AI
              </h2>
              <p className="text-xs sm:text-sm text-slate-400">
                Next-generation intelligence powered by Google Gemini. Ask questions, explore concepts, brainstorm, or solve complex problems.
              </p>
            </div>

            {/* Starter Prompts */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full max-w-xl text-left">
              {starterPrompts.map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => onSendMessage(prompt)}
                  className="p-3 rounded-xl bg-[#140a2c]/70 hover:bg-[#1f1042] border border-purple-900/40 hover:border-purple-500/50 text-xs text-slate-300 hover:text-white transition-all text-left shadow-sm group"
                >
                  <span className="text-purple-400 group-hover:text-purple-300 mr-1.5">✦</span>
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <>
            {messages.map((message) => {
              const isUser = message.role === 'user';
              return (
                <div
                  key={message.id}
                  className={`flex gap-3 sm:gap-4 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-indigo-600 p-0.5 shrink-0 mt-0.5 shadow-md shadow-purple-600/20">
                      <div className="w-full h-full bg-[#0e0724] rounded-[6px] flex items-center justify-center">
                        <Bot className="w-4 h-4 text-purple-300" />
                      </div>
                    </div>
                  )}

                  <div
                    className={`max-w-[88%] sm:max-w-[80%] rounded-2xl p-4 shadow-lg ${
                      isUser
                        ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-tr-sm'
                        : 'bg-[#130a2a] border border-purple-900/50 text-slate-100 rounded-tl-sm neon-border'
                    }`}
                  >
                    {isUser ? (
                      <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
                    ) : (
                      <div className="relative group/msg">
                        <MarkdownRenderer content={message.content} />
                        <div className="mt-2.5 pt-2 border-t border-purple-900/30 flex items-center justify-between text-[11px] text-purple-400/80">
                          <span>KYRO · Gemini Free Tier</span>
                          <button
                            onClick={() => copyMessage(message.id, message.content)}
                            className="flex items-center gap-1 hover:text-purple-200 transition-colors p-1"
                            title="Copy reply"
                          >
                            {copiedId === message.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-emerald-400">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {isUser && (
                    <div className="w-8 h-8 rounded-lg bg-purple-950 border border-purple-700/50 p-0.5 shrink-0 mt-0.5 flex items-center justify-center">
                      <User className="w-4 h-4 text-purple-300" />
                    </div>
                  )}
                </div>
              );
            })}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex gap-3 sm:gap-4 justify-start items-center">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-indigo-600 p-0.5 shrink-0 shadow-md shadow-purple-600/30">
                  <div className="w-full h-full bg-[#0e0724] rounded-[6px] flex items-center justify-center">
                    <Bot className="w-4 h-4 text-purple-300 animate-pulse" />
                  </div>
                </div>
                <div className="rounded-2xl px-4 py-3 bg-[#130a2a] border border-purple-900/50 shadow-lg">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
                    <span className="w-2 h-2 rounded-full bg-purple-400 animate-bounce delay-100" />
                    <span className="w-2 h-2 rounded-full bg-fuchsia-400 animate-bounce delay-200" />
                    <span className="text-xs text-purple-300 font-medium ml-1">
                      KYRO is processing...
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Error Message */}
            {error && (
              <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span>{error}</span>
                </div>
                <button
                  onClick={onRetry}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-red-900/60 hover:bg-red-900 text-white font-medium shrink-0"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Retry</span>
                </button>
              </div>
            )}

            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input Container */}
      <div className="pb-3 pt-2">
        <form
          onSubmit={handleSubmit}
          className="relative rounded-2xl bg-[#120827] border border-purple-500/30 focus-within:border-purple-400 focus-within:shadow-[0_0_20px_rgba(168,85,247,0.35)] transition-all p-1.5 sm:p-2"
        >
          <div className="flex items-end gap-2">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask KYRO anything... (Shift + Enter for new line)"
              rows={1}
              className="flex-1 bg-transparent border-0 resize-none text-sm text-slate-100 placeholder:text-slate-400 focus:outline-none max-h-32 p-1.5 sm:p-2"
              style={{ minHeight: '40px' }}
            />

            <div className="flex items-center gap-1.5 pb-0.5">
              {messages.length > 0 && (
                <button
                  type="button"
                  onClick={onClearHistory}
                  className="p-2 rounded-xl text-slate-400 hover:text-purple-300 hover:bg-purple-950/50 transition-colors"
                  title="Clear conversation"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}

              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="p-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white disabled:opacity-40 disabled:hover:from-purple-600 disabled:hover:to-indigo-600 shadow-md shadow-purple-600/30 transition-all active:scale-95"
                title="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
