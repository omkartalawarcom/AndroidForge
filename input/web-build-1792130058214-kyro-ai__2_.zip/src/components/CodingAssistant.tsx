import React, { useState } from 'react';
import { MarkdownRenderer } from './MarkdownRenderer';
import { Code2, Bug, Play, Sparkles, Copy, Check, Terminal, Cpu } from 'lucide-react';

export const CodingAssistant: React.FC = () => {
  const [language, setLanguage] = useState('Python');
  const [action, setAction] = useState<'debug' | 'explain' | 'generate' | 'optimize' | 'tests'>('debug');
  const [prompt, setPrompt] = useState('');
  const [code, setCode] = useState('');
  const [targetLang, setTargetLang] = useState('TypeScript');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const languages = [
    'Python',
    'JavaScript',
    'TypeScript',
    'Java',
    'C++',
    'C#',
    'Go',
    'Rust',
    'SQL',
    'PHP',
    'HTML/CSS',
  ];

  const handleRun = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() && !code.trim()) return;

    setIsLoading(true);
    setError(null);

    let instruction = `You are KYRO Code Architect.
Language: ${language}
Task: ${action.toUpperCase()}

${prompt ? `Task Description / Error Message / Goal: "${prompt}"\n` : ''}
${code ? `Source Code:\n\`\`\`${language.toLowerCase()}\n${code}\n\`\`\`\n` : ''}

Please deliver a senior-engineer-grade response:
1. Diagnosis / Breakdown of the problem or architecture
2. Complete, corrected / implemented code inside markdown code blocks (\`\`\`${language.toLowerCase()} ... \`\`\`)
3. Explanation of key lines and logic
4. Time & Space Complexity or Performance considerations if applicable.`;

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'coding',
          messages: [{ role: 'user', content: instruction }],
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to process coding request');
      }

      setResult(data.text);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error in coding assistant';
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const copyResult = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto w-full px-3 sm:px-6 py-6 pb-24 lg:pb-12">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2.5 text-purple-400 text-xs font-semibold uppercase tracking-wider mb-1">
          <Code2 className="w-4 h-4" />
          <span>Polyglot Code Engine</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">
          KYRO Coding Assistant
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
          Debug syntax &amp; logical errors, explain complex algorithms, optimize runtime performance, and write unit tests across all major programming languages.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Controls */}
        <div className="lg:col-span-5 bg-[#120827] rounded-2xl border border-purple-900/40 p-4 sm:p-5 shadow-xl space-y-4">
          <form onSubmit={handleRun} className="space-y-4">
            {/* Action selector */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Developer Operation
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'debug', label: 'Debug & Fix Errors', icon: Bug },
                  { id: 'explain', label: 'Explain Code', icon: Terminal },
                  { id: 'optimize', label: 'Refactor & Optimize', icon: Cpu },
                  { id: 'tests', label: 'Write Unit Tests', icon: Play },
                ].map((act) => {
                  const Icon = act.icon;
                  const isActive = action === act.id;
                  return (
                    <button
                      key={act.id}
                      type="button"
                      onClick={() => setAction(act.id as any)}
                      className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-medium transition-all text-left truncate ${
                        isActive
                          ? 'bg-purple-600 text-white shadow-sm shadow-purple-600/30 font-semibold'
                          : 'bg-purple-950/30 text-slate-400 border border-purple-900/40 hover:text-purple-200'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{act.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Language Selector */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Primary Language
              </label>
              <div className="flex flex-wrap gap-1.5">
                {languages.map((lang) => (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => setLanguage(lang)}
                    className={`px-2.5 py-1 rounded-lg text-xs transition-all font-mono ${
                      language === lang
                        ? 'bg-purple-900/80 text-purple-200 border border-purple-500/50 font-bold'
                        : 'bg-purple-950/30 text-slate-400 border border-purple-900/30 hover:text-purple-200'
                    }`}
                  >
                    {lang}
                  </button>
                ))}
              </div>
            </div>

            {/* Error Message or Task Description */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Goal or Error Traceback
              </label>
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g. TypeError: Cannot read property 'map' of undefined, or Implement LRU cache"
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 px-3 py-2 text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-purple-400 transition-all font-mono"
              />
            </div>

            {/* Code Input */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5 flex items-center justify-between">
                <span>Code Snippet</span>
                <span className="text-[10px] text-slate-400 font-mono">paste snippet</span>
              </label>
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder={`// Paste your ${language} code here...`}
                rows={7}
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 p-3 text-xs text-purple-200 font-mono placeholder:text-slate-500 focus:outline-none focus:border-purple-400 transition-all resize-y"
                spellCheck={false}
              />
            </div>

            <button
              type="submit"
              disabled={(!prompt.trim() && !code.trim()) || isLoading}
              className="w-full rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs py-2.5 shadow-lg shadow-purple-600/30 transition-all disabled:opacity-40 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin text-purple-200" />
                  <span>Analyzing &amp; Compiling Fix...</span>
                </>
              ) : (
                <>
                  <Code2 className="w-4 h-4" />
                  <span>Execute Code Assistance</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Output */}
        <div className="lg:col-span-7 bg-[#120827] rounded-2xl border border-purple-900/40 p-5 shadow-xl min-h-[420px] flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-4">
            <div className="flex items-center gap-2 text-xs text-purple-300 font-semibold font-mono">
              <Terminal className="w-4 h-4 text-purple-400" />
              <span>TERMINAL OUTPUT · {language.toUpperCase()}</span>
            </div>

            {result && (
              <button
                onClick={copyResult}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 text-xs text-purple-300 hover:text-white border border-purple-800/40 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy All'}</span>
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 space-y-3">
                <div className="w-12 h-12 rounded-xl bg-purple-950/60 border border-purple-500/40 flex items-center justify-center animate-pulse">
                  <Terminal className="w-6 h-6 text-purple-400" />
                </div>
                <p className="text-xs text-purple-300 font-mono">
                  Tracing call stack &amp; synthesizing optimized code...
                </p>
              </div>
            ) : error ? (
              <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs font-mono">
                {error}
              </div>
            ) : result ? (
              <div className="space-y-4">
                <MarkdownRenderer content={result} />
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 text-slate-400 space-y-2">
                <Code2 className="w-10 h-10 text-purple-500/40" />
                <p className="text-xs">
                  Select your operation, choose a programming language, and paste your code or error message.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
