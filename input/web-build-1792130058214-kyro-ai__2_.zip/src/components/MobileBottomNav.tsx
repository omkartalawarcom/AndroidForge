import React from 'react';
import { ActiveTab } from '../types';
import { MessageSquare, GraduationCap, PenTool, Code2, Globe2, Image as ImageIcon } from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ activeTab, onTabChange }) => {
  const tabs: { id: ActiveTab; label: string; icon: React.ElementType }[] = [
    { id: 'chat', label: 'Chat', icon: MessageSquare },
    { id: 'study', label: 'Study', icon: GraduationCap },
    { id: 'writing', label: 'Write', icon: PenTool },
    { id: 'coding', label: 'Code', icon: Code2 },
    { id: 'translator', label: 'Translate', icon: Globe2 },
    { id: 'image', label: 'Studio', icon: ImageIcon },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0b051c]/95 backdrop-blur-xl border-t border-purple-900/40 pb-safe shadow-[0_-4px_20px_rgba(0,0,0,0.6)]">
      <div className="grid grid-cols-6 items-center h-16 max-w-md mx-auto px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="flex flex-col items-center justify-center min-h-[44px] py-1 text-center transition-all group"
            >
              <div
                className={`p-1 rounded-xl transition-all ${
                  isActive
                    ? 'bg-purple-600/30 text-purple-300 shadow-sm shadow-purple-500/30 scale-105'
                    : 'text-slate-400 group-hover:text-slate-200'
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span
                className={`text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap ${
                  isActive ? 'text-purple-300 font-semibold' : 'text-slate-400'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
