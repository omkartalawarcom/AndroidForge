import React, { useState } from 'react';
import { MarkdownRenderer } from './MarkdownRenderer';
import { Image as ImageIcon, Sparkles, Wand2, Copy, Check, Info, Sliders, AlertCircle, Layers } from 'lucide-react';

export const ImageStudio: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState('Cyberpunk Neon');
  const [lighting, setLighting] = useState('Purple & Cyan Neon Rim');
  const [perspective, setPerspective] = useState('Cinematic Wide Angle');
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [resultPrompt, setResultPrompt] = useState<string | null>(null);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [limitationNotice, setLimitationNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const styles = [
    'Cyberpunk Neon',
    'Photorealistic 8K',
    'Anime / Manga',
    '3D Octane Render',
    'Synthwave Retro',
    'Cinematic Concept Art',
    'Dark Fantasy',
    'Minimalist Vector',
  ];

  const lightings = [
    'Purple & Cyan Neon Rim',
    'Softbox Studio Lighting',
    'Volumetric Golden Hour',
    'Dramatic Chiaroscuro',
    'Bioluminescent Glow',
  ];

  const perspectives = [
    'Cinematic Wide Angle',
    'Macro Close-Up',
    'Isometric 3D View',
    'Low-Angle Hero Shot',
    'Overhead Drone Aerial',
  ];

  const aspectRatios = [
    { label: '16:9 Landscape', value: '16:9' },
    { label: '1:1 Square', value: '1:1' },
    { label: '9:16 Mobile Story', value: '9:16' },
    { label: '4:3 Standard', value: '4:3' },
  ];

  const sampleIdeas = [
    'A futuristic robotic tiger walking down a neon-lit rain-slicked Tokyo alley',
    'A cosmic observatory situated on the rings of Saturn overlooking the nebula',
    'A high-tech cybernetic neural interface headset glowing with violet fiber optics',
    'An ancient fantasy temple enveloped by crystalline purple flora',
  ];

  // 1. Craft Master Prompt via Gemini 3.8 Flash (Free Tier)
  const handleEnhancePrompt = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!prompt.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setLimitationNotice(null);

    try {
      const res = await fetch('/api/image-studio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          style,
          lighting,
          perspective,
          aspectRatio,
          action: 'enhance',
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to craft prompt');
      }

      setResultPrompt(data.masterPrompt);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error crafting image prompt';
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Test Live Generation (with honest explanation if billing account is required)
  const handleTestGeneration = async () => {
    if (!prompt.trim() || isGeneratingImage) return;

    setIsGeneratingImage(true);
    setLimitationNotice(null);
    setGeneratedImageUrl(null);
    setError(null);

    try {
      const res = await fetch('/api/image-studio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          style,
          lighting,
          perspective,
          aspectRatio,
          action: 'generate',
        }),
      });

      const data = await res.json();
      if (data.imageUrl) {
        setGeneratedImageUrl(data.imageUrl);
      } else {
        setLimitationNotice(
          data.limitationNotice ||
            'Gemini image generation models (gemini-3.1-flash-lite-image) require a Google Cloud billing account / paid tier API key. Your master prompt package is generated below ready to paste into any image generator.'
        );
        // Also ensure prompt is generated so user has immediate value
        if (!resultPrompt) {
          handleEnhancePrompt();
        }
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error connecting to image endpoint';
      setLimitationNotice(
        `Gemini image generation requires a Google Cloud billing account (${msg}). KYRO has generated your full master prompt below for use with Midjourney, Imagen, or Stable Diffusion.`
      );
      if (!resultPrompt) {
        handleEnhancePrompt();
      }
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const copyPrompt = () => {
    if (!resultPrompt) return;
    navigator.clipboard.writeText(resultPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto w-full px-3 sm:px-6 py-6 pb-24 lg:pb-12">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2.5 text-purple-400 text-xs font-semibold uppercase tracking-wider mb-1">
          <ImageIcon className="w-4 h-4" />
          <span>Generative Vision Studio</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">
          KYRO Image Studio
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
          Architect production-grade visual concepts, lighting setups, and multi-parameter master prompts formatted for Imagen 3, Midjourney, and Stable Diffusion.
        </p>
      </div>

      {/* Honest Architecture & Free-Tier Transparency Notice */}
      <div className="mb-6 p-4 rounded-2xl bg-purple-950/30 border border-purple-800/40 text-xs text-slate-300 flex items-start gap-3">
        <Info className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-purple-200">
            API Architecture &amp; Free Tier Notice
          </p>
          <p className="text-slate-400 leading-relaxed">
            All text, logic, coding, and prompt architecture in KYRO AI are powered by Google Gemini on the free tier. Native pixel image generation models (<span className="text-purple-300 font-mono">gemini-3.1-flash-lite-image</span> or Imagen) require a paid Google Cloud billing account. KYRO AI crafts complete production prompt packages with negative prompts and render tags, and verifies live image generation if paid credentials exist.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Controls */}
        <div className="lg:col-span-5 bg-[#120827] rounded-2xl border border-purple-900/40 p-4 sm:p-5 shadow-xl space-y-4">
          <form onSubmit={handleEnhancePrompt} className="space-y-4">
            {/* Visual Concept Idea Input */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Core Visual Idea
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe what you want to visualize (e.g. A futuristic neon cyberspace city with floating purple monoliths)..."
                rows={3}
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 p-3 text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-purple-400 focus:shadow-[0_0_15px_rgba(168,85,247,0.25)] transition-all resize-y"
              />
            </div>

            {/* Quick Inspiration Chips */}
            <div>
              <span className="text-[11px] text-purple-400/80 font-medium block mb-1">
                Quick inspiration ideas:
              </span>
              <div className="flex flex-col gap-1.5">
                {sampleIdeas.slice(0, 2).map((idea, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPrompt(idea)}
                    className="text-left text-[11px] text-slate-300 hover:text-purple-200 p-2 rounded-lg bg-purple-950/40 hover:bg-purple-900/40 border border-purple-900/30 truncate transition-colors"
                  >
                    ✦ {idea}
                  </button>
                ))}
              </div>
            </div>

            {/* Visual Art Style */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Artistic Style
              </label>
              <div className="flex flex-wrap gap-1.5">
                {styles.map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setStyle(st)}
                    className={`px-2.5 py-1 rounded-lg text-xs transition-all ${
                      style === st
                        ? 'bg-purple-600 text-white shadow-sm shadow-purple-600/30 font-semibold'
                        : 'bg-purple-950/30 text-slate-400 border border-purple-900/30 hover:text-purple-200'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* Lighting Profile */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Atmosphere &amp; Lighting
              </label>
              <select
                value={lighting}
                onChange={(e) => setLighting(e.target.value)}
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-purple-400"
              >
                {lightings.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>

            {/* Camera Perspective */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Camera Perspective
              </label>
              <select
                value={perspective}
                onChange={(e) => setPerspective(e.target.value)}
                className="w-full rounded-xl bg-[#0a0518] border border-purple-900/50 px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-purple-400"
              >
                {perspectives.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>

            {/* Aspect Ratio */}
            <div>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5">
                Aspect Ratio
              </label>
              <div className="grid grid-cols-2 gap-2">
                {aspectRatios.map((ar) => (
                  <button
                    key={ar.value}
                    type="button"
                    onClick={() => setAspectRatio(ar.value)}
                    className={`py-1.5 px-2 rounded-xl text-xs transition-all text-center ${
                      aspectRatio === ar.value
                        ? 'bg-purple-900/80 text-purple-200 border border-purple-500/50 font-bold'
                        : 'bg-purple-950/30 text-slate-400 border border-purple-900/30 hover:text-purple-200'
                    }`}
                  >
                    {ar.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Dual Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                type="submit"
                disabled={!prompt.trim() || isLoading}
                className="w-full rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs py-2.5 shadow-lg shadow-purple-600/30 transition-all disabled:opacity-40 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Sparkles className="w-4 h-4 animate-spin text-purple-200" />
                    <span>Architecting Master Prompt...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4" />
                    <span>Generate Master Prompt &amp; Parameters</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleTestGeneration}
                disabled={!prompt.trim() || isGeneratingImage}
                className="w-full rounded-xl bg-purple-950/70 hover:bg-purple-900/70 border border-purple-500/40 text-purple-200 hover:text-white font-medium text-xs py-2 transition-all disabled:opacity-40 flex items-center justify-center gap-2"
              >
                {isGeneratingImage ? (
                  <>
                    <Sparkles className="w-4 h-4 animate-spin text-purple-300" />
                    <span>Contacting Image Model...</span>
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-4 h-4 text-purple-400" />
                    <span>Test Direct Image Generation</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Output Canvas */}
        <div className="lg:col-span-7 bg-[#120827] rounded-2xl border border-purple-900/40 p-5 shadow-xl min-h-[460px] flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-4">
            <div className="flex items-center gap-2 text-xs text-purple-300 font-semibold">
              <Sliders className="w-4 h-4 text-purple-400" />
              <span>Studio Visual Output</span>
            </div>

            {resultPrompt && (
              <button
                onClick={copyPrompt}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 text-xs text-purple-300 hover:text-white border border-purple-800/40 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Prompt Package'}</span>
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto space-y-4">
            {/* If an actual image was generated */}
            {generatedImageUrl && (
              <div className="rounded-xl overflow-hidden border border-purple-500/40 bg-[#090514] shadow-2xl p-2">
                <img
                  src={generatedImageUrl}
                  alt={prompt}
                  className="w-full rounded-lg object-contain max-h-[380px] mx-auto"
                />
                <div className="p-3 text-xs text-purple-300 flex justify-between items-center">
                  <span>Generated with Gemini Image Model</span>
                  <a
                    href={generatedImageUrl}
                    download="kyro-ai-artwork.png"
                    className="px-3 py-1 rounded bg-purple-600 hover:bg-purple-500 text-white font-medium"
                  >
                    Download Image
                  </a>
                </div>
              </div>
            )}

            {/* If there is a limitation notice */}
            {limitationNotice && (
              <div className="p-4 rounded-xl bg-purple-950/60 border border-purple-700/50 text-purple-200 text-xs flex items-start gap-3">
                <AlertCircle className="w-4 h-4 text-purple-300 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white">Notice regarding Image Generation API</p>
                  <p className="text-slate-300 mt-1 leading-relaxed">{limitationNotice}</p>
                </div>
              </div>
            )}

            {isLoading || isGeneratingImage ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 space-y-3">
                <div className="w-12 h-12 rounded-xl bg-purple-950/60 border border-purple-500/40 flex items-center justify-center animate-pulse">
                  <Wand2 className="w-6 h-6 text-purple-400" />
                </div>
                <p className="text-xs text-purple-300 font-medium">
                  {isGeneratingImage
                    ? 'Verifying image generation endpoint...'
                    : 'KYRO Vision Engine is engineering cinematic parameters...'}
                </p>
              </div>
            ) : error ? (
              <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs">
                {error}
              </div>
            ) : resultPrompt ? (
              <div className="space-y-4">
                <div className="p-3 rounded-xl bg-[#090514] border border-purple-900/40 flex flex-wrap gap-2 text-xs">
                  <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800/40 font-mono">
                    --ar {aspectRatio}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800/40 font-mono">
                    Style: {style}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800/40 font-mono">
                    Optics: {perspective}
                  </span>
                </div>
                <MarkdownRenderer content={resultPrompt} />
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 text-slate-400 space-y-2">
                <Layers className="w-10 h-10 text-purple-500/40" />
                <p className="text-xs">
                  Enter your visual idea, choose lighting &amp; camera perspective, and click to synthesize a master prompt package.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
