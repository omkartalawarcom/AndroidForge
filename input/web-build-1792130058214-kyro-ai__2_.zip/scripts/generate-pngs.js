import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function createPNG(width, height, isMaskable = false) {
  // RGBA buffer (4 bytes per pixel) + 1 filter byte per scanline
  const scanlineLength = width * 4 + 1;
  const rawData = Buffer.alloc(scanlineLength * height);

  const cx = width / 2;
  const cy = height / 2;
  const safeRadius = isMaskable ? width * 0.38 : width * 0.44;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * scanlineLength;
    rawData[rowOffset] = 0; // Filter type 0 (None)

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Deep dark futuristic background: #0c071e
      let r = 12;
      let g = 7;
      let b = 30;
      let a = 255;

      // Soft purple radial glow
      if (dist < width * 0.45) {
        const glowFactor = (1 - dist / (width * 0.45)) * 0.6;
        r = Math.min(255, Math.floor(r + 140 * glowFactor));
        g = Math.min(255, Math.floor(g + 40 * glowFactor));
        b = Math.min(255, Math.floor(b + 220 * glowFactor));
      }

      // Draw futuristic K shape
      // Normalize coords to [-1, 1] inside safe zone
      const nx = (x - cx) / (safeRadius * 0.85);
      const ny = (y - cy) / (safeRadius * 0.85);

      let inK = false;
      let isCore = false;

      // Spine of K: nx between -0.45 and -0.15, ny between -0.7 and 0.7
      if (nx >= -0.45 && nx <= -0.15 && ny >= -0.7 && ny <= 0.7) {
        inK = true;
      }
      // Top branch: y = -x
      const dTop = (nx - (-0.15)) - (-ny);
      if (nx >= -0.15 && nx <= 0.55 && ny <= 0.05 && ny >= -0.7) {
        if (Math.abs(dTop) <= 0.22) {
          inK = true;
        }
      }
      // Bottom branch: y = x
      const dBot = (nx - (-0.15)) - (ny);
      if (nx >= -0.15 && nx <= 0.55 && ny >= -0.05 && ny <= 0.7) {
        if (Math.abs(dBot) <= 0.22) {
          inK = true;
        }
      }

      // Center bright core
      if (Math.sqrt((nx - (-0.15))**2 + ny**2) < 0.12) {
        isCore = true;
      }

      if (isCore) {
        r = 255;
        g = 255;
        b = 255;
        a = 255;
      } else if (inK) {
        // Bright neon violet/magenta
        const grad = (ny + 0.7) / 1.4;
        r = Math.floor(217 * (1 - grad) + 168 * grad);
        g = Math.floor(70 * (1 - grad) + 85 * grad);
        b = Math.floor(239 * (1 - grad) + 247 * grad);
        a = 255;
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  // Compress raw data with zlib
  const compressed = zlib.deflateSync(rawData);

  // Build PNG chunks
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8); // bit depth
  ihdr.writeUInt8(6, 9); // RGBA
  ihdr.writeUInt8(0, 10); // compression
  ihdr.writeUInt8(0, 11); // filter
  ihdr.writeUInt8(0, 12); // interlace

  const ihdrChunk = createChunk('IHDR', ihdr);
  const idatChunk = createChunk('IDAT', compressed);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const len = data.length;
  const buf = Buffer.alloc(12 + len);
  buf.writeUInt32BE(len, 0);
  buf.write(type, 4, 4, 'ascii');
  data.copy(buf, 8);
  const crc = crc32(buf.subarray(4, 8 + len));
  buf.writeUInt32BE(crc >>> 0, 8 + len);
  return buf;
}

// Standard CRC32 table
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return c ^ 0xffffffff;
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPNG(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPNG(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPNG(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPNG(180, 180, false));
console.log('Generated PNG icons successfully.');
