# KYRO AI - Native Android Application

A premium, high-performance native Android application built with **Kotlin** and **Jetpack Compose**, featuring an electric purple neon aesthetic matching KYRO AI.

## 🚀 Key Features

1. **AI Chat**: Conversational AI assistant powered by Gemini with conversation history and fast reasoning.
2. **Study Assistant**: Topic explainers, interactive quizzes, high-yield flashcards, and executive summaries.
3. **Writing Assistant**: Eloquent composition, tone shifter (Professional, Academic, Persuasive, Casual), and grammar polish.
4. **Code Assistant**: Polyglot code generator, bug detector, refactoring engine, and algorithmic complexity analyzer.
5. **Translator**: Contextual translation with phonetic pronunciation guides and formality adjustments.
6. **AI Studio**: Prompt engineering playground with temperature tuning, system instruction experimentation, and JSON output mode.

---

## 🔒 Security Architecture (Zero Client-Side Key Exposure)

In accordance with strict security standards:
- **No Gemini API keys are bundled inside the Android APK**.
- The Android app connects to the **KYRO AI Secure Backend Server** (`server.ts`) via Retrofit and OkHttp.
- The backend manages secure communication with `@google/genai` using server-side environment credentials.

---

## 🛠️ Project Structure

```
android/
├── app/
│   ├── build.gradle.kts           # App module dependencies & SDK config (SDK 35, Java 17)
│   ├── proguard-rules.pro         # Proguard/R8 obfuscation rules
│   └── src/main/
│       ├── AndroidManifest.xml    # Permissions (INTERNET) & MainActivity declaration
│       ├── res/
│       │   └── values/            # strings.xml, colors.xml, themes.xml
│       └── java/com/kyro/ai/
│           ├── MainActivity.kt    # Root Compose Activity & Navigation Scaffold
│           ├── KyroApplication.kt # Android Application class
│           ├── ui/
│           │   ├── theme/         # Color.kt, Theme.kt (Purple Neon palette), Type.kt
│           │   ├── components/    # KyroNeonCard, KyroGlowButton, KyroBottomBar, KyroHeader
│           │   ├── navigation/    # Screen sealed class and routes
│           │   └── screens/
│           │       ├── chat/      # ChatScreen.kt
│           │       ├── study/     # StudyScreen.kt
│           │       ├── writing/   # WritingScreen.kt
│           │       ├── code/      # CodeScreen.kt
│           │       ├── translator/# TranslatorScreen.kt
│           │       └── studio/    # StudioScreen.kt
│           └── data/
│               ├── model/         # Models.kt (Chat, Study, Writing, Code, Translate, Studio DTOs)
│               ├── api/           # KyroApiService.kt & ApiClient.kt (Retrofit/OkHttp)
│               └── repository/    # KyroRepository.kt (Coroutines & Result wrappers)
├── build.gradle.kts               # Top-level build file
├── settings.gradle.kts            # Project repositories & module includes
└── gradle/
    └── libs.versions.toml         # Version catalog (Compose BOM, AGP 8.7, Retrofit)
```

---

## 💻 How to Run in Android Studio

1. Open **Android Studio** (Ladybug, Koala, or Jellyfish).
2. Click **Open** and select the `android/` directory.
3. Allow Gradle to sync dependencies (requires JDK 17).
4. Run the app on an Android Emulator or physical device (Min SDK: 26, Target SDK: 35).
5. To point to your own local or hosted backend, update `BASE_URL` in `ApiClient.kt` or `app/build.gradle.kts`.
