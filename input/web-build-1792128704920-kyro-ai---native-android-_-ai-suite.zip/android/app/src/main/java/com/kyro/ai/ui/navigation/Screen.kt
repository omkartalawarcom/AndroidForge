package com.kyro.ai.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Translate
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector,
    val badge: String? = null
) {
    object Chat : Screen("chat", "AI Chat", Icons.Default.ChatBubble)
    object Study : Screen("study", "Study", Icons.Default.School)
    object Writing : Screen("writing", "Writing", Icons.Default.EditNote)
    object Code : Screen("code", "Code", Icons.Default.Code)
    object Translator : Screen("translator", "Translate", Icons.Default.Translate)
    object Studio : Screen("studio", "AI Studio", Icons.Default.AutoAwesome, "PRO")

    companion object {
        val bottomNavItems = listOf(Chat, Study, Writing, Code, Translator, Studio)
    }
}
