package com.kyro.ai.data.repository

import com.kyro.ai.data.api.ApiClient
import com.kyro.ai.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class KyroRepository {
    private val api = ApiClient.apiService

    suspend fun chat(messages: List<ChatMessagePayload>, systemInstruction: String? = null): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val response = api.sendChatMessage(ChatRequest(messages, systemInstruction))
                Result.success(response.reply)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun study(mode: String, topic: String, level: String?): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val response = api.getStudyAssistance(StudyRequest(mode, topic, level))
                Result.success(response.reply)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun writing(action: String, content: String, tone: String?, targetLength: String?): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val response = api.getWritingAssistance(WritingRequest(action, content, tone, targetLength))
                Result.success(response.reply)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun code(action: String, codeOrPrompt: String, language: String): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val response = api.getCodeAssistance(CodeRequest(action, codeOrPrompt, language))
                Result.success(response.reply)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun translate(text: String, sourceLang: String, targetLang: String, formality: String?): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val response = api.translateText(TranslateRequest(text, sourceLang, targetLang, formality))
                Result.success(response.reply)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun studio(systemPrompt: String, userPrompt: String, temperature: Float, jsonMode: Boolean): Result<StudioResponse> =
        withContext(Dispatchers.IO) {
            try {
                val response = api.executeStudioPrompt(StudioRequest(systemPrompt, userPrompt, temperature, jsonMode))
                Result.success(response)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
