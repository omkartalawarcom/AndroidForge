package com.kyro.ai.ui.theme

import androidx.compose.ui.graphics.Color

// KYRO AI Premium Purple Neon Palette
val NeonPurplePrimary = Color(0xFFA855F7)
val NeonPurpleLight = Color(0xFFC084FC)
val NeonPurpleDark = Color(0xFF7E22CE)
val NeonPinkAccent = Color(0xFFEC4899)
val NeonCyanAccent = Color(0xFF06B6D4)
val NeonGlow = Color(0xFFD946EF)

// Dark obsidian background & surfaces
val DarkBackground = Color(0xFF0B0816)
val DarkSurface = Color(0xFF130E26)
val DarkSurfaceVariant = Color(0xFF1E163B)
val DarkCardBackground = Color(0xFF181230)
val DarkBorder = Color(0xFF382361)

// Text & Content Colors
val TextPrimary = Color(0xFFF3E8FF)
val TextSecondary = Color(0xFFC4B5FD)
val TextMuted = Color(0xFF9381BF)
val TextHighlight = Color(0xFFE9D5FF)

val StatusSuccess = Color(0xFF10B981)
val StatusError = Color(0xFFEF4444)
