package com.kyro.ai.data.model

import com.google.gson.annotations.SerializedName

// 1. Chat Models
data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: String, // "user" or "model"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatRequest(
    @SerializedName("messages") val messages: List<ChatMessagePayload>,
    @SerializedName("systemInstruction") val systemInstruction: String? = null
)

data class ChatMessagePayload(
    @SerializedName("role") val role: String,
    @SerializedName("text") val text: String
)

data class ChatResponse(
    @SerializedName("reply") val reply: String
)

// 2. Study Assistant Models
data class StudyRequest(
    @SerializedName("mode") val mode: String, // "quiz", "flashcards", "summarize", "explain"
    @SerializedName("topic") val topic: String,
    @SerializedName("level") val level: String? = null
)

data class StudyResponse(
    @SerializedName("reply") val reply: String
)

// 3. Writing Assistant Models
data class WritingRequest(
    @SerializedName("action") val action: String, // "essay", "tone", "grammar", "paraphrase"
    @SerializedName("content") val content: String,
    @SerializedName("tone") val tone: String? = null,
    @SerializedName("targetLength") val targetLength: String? = null
)

data class WritingResponse(
    @SerializedName("reply") val reply: String
)

// 4. Code Assistant Models
data class CodeRequest(
    @SerializedName("action") val action: String, // "generate", "debug", "refactor", "explain"
    @SerializedName("codeOrPrompt") val codeOrPrompt: String,
    @SerializedName("language") val language: String
)

data class CodeResponse(
    @SerializedName("reply") val reply: String
)

// 5. Translator Models
data class TranslateRequest(
    @SerializedName("text") val text: String,
    @SerializedName("sourceLang") val sourceLang: String,
    @SerializedName("targetLang") val targetLang: String,
    @SerializedName("formality") val formality: String? = null
)

data class TranslateResponse(
    @SerializedName("reply") val reply: String
)

// 6. AI Studio Models
data class StudioRequest(
    @SerializedName("systemPrompt") val systemPrompt: String,
    @SerializedName("userPrompt") val userPrompt: String,
    @SerializedName("temperature") val temperature: Float = 0.7f,
    @SerializedName("jsonMode") val jsonMode: Boolean = false
)

data class StudioResponse(
    @SerializedName("reply") val reply: String,
    @SerializedName("model") val model: String?,
    @SerializedName("usage") val usage: Any?
)
