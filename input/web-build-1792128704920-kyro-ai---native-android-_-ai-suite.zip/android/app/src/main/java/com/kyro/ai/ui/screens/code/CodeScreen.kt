package com.kyro.ai.ui.screens.code

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyro.ai.data.repository.KyroRepository
import com.kyro.ai.ui.components.KyroGlowButton
import com.kyro.ai.ui.components.KyroNeonCard
import com.kyro.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun CodeScreen(
    repository: KyroRepository = remember { KyroRepository() }
) {
    var codeOrPrompt by remember { mutableStateOf("") }
    var selectedAction by remember { mutableStateOf("generate") }
    var selectedLang by remember { mutableStateOf("Kotlin") }
    var resultText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    val actions = listOf(
        "generate" to "Generate",
        "debug" to "Debug",
        "refactor" to "Refactor",
        "explain" to "Explain"
    )

    val languages = listOf("Kotlin", "TypeScript", "Python", "Rust", "Swift", "Java", "Go", "C++")

    fun runCodeAction() {
        if (codeOrPrompt.isBlank() || isLoading) return
        isLoading = true
        scope.launch {
            val result = repository.code(selectedAction, codeOrPrompt, selectedLang)
            result.onSuccess {
                resultText = it
                copied = false
            }.onFailure {
                resultText = "Code operation failed: ${it.localizedMessage}"
            }
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Language Selector horizontal pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            languages.forEach { lang ->
                val isSelected = selectedLang == lang
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) NeonPurplePrimary else DarkSurfaceVariant)
                        .border(1.dp, if (isSelected) NeonPurpleLight else DarkBorder, RoundedCornerShape(8.dp))
                        .clickable { selectedLang = lang }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = lang,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else TextSecondary
                    )
                }
            }
        }

        // Action Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            actions.forEach { (actionKey, actionTitle) ->
                val isSelected = selectedAction == actionKey
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) NeonPurplePrimary else DarkSurfaceVariant)
                        .border(1.dp, if (isSelected) NeonPurpleLight else DarkBorder, RoundedCornerShape(10.dp))
                        .clickable { selectedAction = actionKey }
                        .padding(vertical = 10.dp, horizontal = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = actionTitle,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else TextSecondary,
                        maxLines = 1
                    )
                }
            }
        }

        // Code Editor Input Box
        KyroNeonCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Specification or Code Snippet",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = selectedLang,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonCyanAccent
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = codeOrPrompt,
                onValueChange = { codeOrPrompt = it },
                placeholder = {
                    Text(
                        "e.g. Write a Jetpack Compose ViewModel with StateFlow, or paste code to debug...",
                        color = TextMuted,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = NeonPurplePrimary,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                minLines = 5,
                maxLines = 10
            )
        }

        // Action Button
        KyroGlowButton(
            text = "Execute Code Assistant",
            onClick = { runCodeAction() },
            isLoading = isLoading,
            enabled = codeOrPrompt.isNotBlank(),
            icon = Icons.Default.Code
        )

        // Result Card (Code Output)
        if (resultText.isNotBlank()) {
            KyroNeonCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NeonPurpleLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Engineered Solution",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonPurpleLight
                        )
                    }

                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(resultText))
                            copied = true
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = if (copied) StatusSuccess else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF07050E))
                        .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = resultText,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFE2E8F0)
                    )
                }
            }
        }
    }
}
