package com.kyro.ai.ui.screens.study

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyro.ai.data.repository.KyroRepository
import com.kyro.ai.ui.components.KyroGlowButton
import com.kyro.ai.ui.components.KyroNeonCard
import com.kyro.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun StudyScreen(
    repository: KyroRepository = remember { KyroRepository() }
) {
    var topic by remember { mutableStateOf("") }
    var selectedMode by remember { mutableStateOf("explain") }
    var selectedLevel by remember { mutableStateOf("Intermediate") }
    var resultText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    val modes = listOf(
        "explain" to "Explain Topic",
        "quiz" to "Interactive Quiz",
        "flashcards" to "Flashcards",
        "summarize" to "Executive Summary"
    )

    val levels = listOf("Beginner", "Intermediate", "Advanced", "PhD / Expert")

    fun generateStudyAid() {
        if (topic.isBlank() || isLoading) return
        isLoading = true
        scope.launch {
            val result = repository.study(selectedMode, topic, selectedLevel)
            result.onSuccess {
                resultText = it
                copied = false
            }.onFailure {
                resultText = "Failed to generate study guide: ${it.localizedMessage}"
            }
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Mode Selector Chips
        Text(
            text = "Select Study Mode",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            modes.forEach { (modeKey, modeTitle) ->
                val isSelected = selectedMode == modeKey
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) NeonPurplePrimary else DarkSurfaceVariant)
                        .border(1.dp, if (isSelected) NeonPurpleLight else DarkBorder, RoundedCornerShape(10.dp))
                        .clickable { selectedMode = modeKey }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = modeTitle,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else TextSecondary,
                        maxLines = 1
                    )
                }
            }
        }

        // Topic Input Card
        KyroNeonCard {
            Text(
                text = "Subject / Learning Material",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = topic,
                onValueChange = { topic = it },
                placeholder = {
                    Text(
                        "e.g. Dijkstra's Algorithm, Cellular Respiration, Roman Empire economics...",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = NeonPurplePrimary,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                minLines = 3,
                maxLines = 6
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Difficulty Level Row
            Text(
                text = "Target Mastery Level",
                fontSize = 12.sp,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                levels.forEach { level ->
                    val isSel = selectedLevel == level
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSel) NeonPurpleDark.copy(alpha = 0.5f) else DarkSurface)
                            .border(1.dp, if (isSel) NeonPurpleLight else DarkBorder, RoundedCornerShape(8.dp))
                            .clickable { selectedLevel = level }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = level,
                            fontSize = 10.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSel) TextHighlight else TextMuted
                        )
                    }
                }
            }
        }

        // Action Button
        KyroGlowButton(
            text = "Generate Accelerated Study Aid",
            onClick = { generateStudyAid() },
            isLoading = isLoading,
            enabled = topic.isNotBlank(),
            icon = Icons.Default.School
        )

        // Result Card
        if (resultText.isNotBlank()) {
            KyroNeonCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NeonPurpleLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Kyro Learning Output",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonPurpleLight
                        )
                    }

                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(resultText))
                            copied = true
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = if (copied) StatusSuccess else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = DarkBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = resultText,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = TextPrimary
                )
            }
        }
    }
}
