package com.kyro.ai

import android.app.Application

class KyroApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize logging or app-wide configurations
    }
}
