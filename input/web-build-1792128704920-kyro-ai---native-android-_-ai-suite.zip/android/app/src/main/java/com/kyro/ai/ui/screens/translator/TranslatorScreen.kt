package com.kyro.ai.ui.screens.translator

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyro.ai.data.repository.KyroRepository
import com.kyro.ai.ui.components.KyroGlowButton
import com.kyro.ai.ui.components.KyroNeonCard
import com.kyro.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun TranslatorScreen(
    repository: KyroRepository = remember { KyroRepository() }
) {
    var sourceText by remember { mutableStateOf("") }
    var sourceLang by remember { mutableStateOf("English") }
    var targetLang by remember { mutableStateOf("Spanish") }
    var selectedFormality by remember { mutableStateOf("Natural") }
    var resultText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    val popularLangs = listOf("English", "Spanish", "French", "German", "Japanese", "Mandarin", "Hindi", "Arabic")
    val formalities = listOf("Natural", "Casual / Slang", "Polite / Formal", "Diplomatic")

    fun swapLanguages() {
        val temp = sourceLang
        sourceLang = targetLang
        targetLang = temp
        if (resultText.isNotBlank()) {
            sourceText = resultText
            resultText = ""
        }
    }

    fun executeTranslate() {
        if (sourceText.isBlank() || isLoading) return
        isLoading = true
        scope.launch {
            val result = repository.translate(sourceText, sourceLang, targetLang, selectedFormality)
            result.onSuccess {
                resultText = it
                copied = false
            }.onFailure {
                resultText = "Translation failed: ${it.localizedMessage}"
            }
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Language Selector Row with Swap Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Source Lang Box
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurfaceVariant)
                    .border(1.dp, NeonPurplePrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(vertical = 12.dp, horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = sourceLang,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary
                )
            }

            IconButton(
                onClick = { swapLanguages() },
                modifier = Modifier
                    .padding(horizontal = 8.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant)
                    .border(1.dp, NeonPurpleLight.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.SwapHoriz,
                    contentDescription = "Swap Languages",
                    tint = NeonPurpleLight
                )
            }

            // Target Lang Box
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurfaceVariant)
                    .border(1.dp, NeonPurplePrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(vertical = 12.dp, horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = targetLang,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = NeonPurpleLight
                )
            }
        }

        // Quick Target Language Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            popularLangs.take(5).forEach { lang ->
                val isSel = targetLang == lang
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSel) NeonPurpleDark.copy(alpha = 0.5f) else DarkSurface)
                        .border(1.dp, if (isSel) NeonPurpleLight else DarkBorder, RoundedCornerShape(8.dp))
                        .clickable { targetLang = lang }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = lang,
                        fontSize = 10.sp,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSel) TextHighlight else TextMuted,
                        maxLines = 1
                    )
                }
            }
        }

        // Source Input Card
        KyroNeonCard {
            Text(
                text = "Enter text in $sourceLang",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = sourceText,
                onValueChange = { sourceText = it },
                placeholder = {
                    Text(
                        "Type or paste text to translate...",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = NeonPurplePrimary,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                minLines = 4,
                maxLines = 7
            )
        }

        // Formality Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            formalities.forEach { f ->
                val isSel = selectedFormality == f
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSel) NeonPurplePrimary else DarkSurfaceVariant)
                        .border(1.dp, if (isSel) NeonPurpleLight else DarkBorder, RoundedCornerShape(8.dp))
                        .clickable { selectedFormality = f }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = f,
                        fontSize = 10.sp,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSel) Color.White else TextSecondary,
                        maxLines = 1
                    )
                }
            }
        }

        // Translate Button
        KyroGlowButton(
            text = "Translate with Linguistic Nuances",
            onClick = { executeTranslate() },
            isLoading = isLoading,
            enabled = sourceText.isNotBlank(),
            icon = Icons.Default.Translate
        )

        // Translation Result Card
        if (resultText.isNotBlank()) {
            KyroNeonCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NeonPurpleLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Translated into $targetLang",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonPurpleLight
                        )
                    }

                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(resultText))
                            copied = true
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = if (copied) StatusSuccess else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = DarkBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = resultText,
                    fontSize = 13.sp,
                    lineHeight = 22.sp,
                    color = TextPrimary
                )
            }
        }
    }
}
