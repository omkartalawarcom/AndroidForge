package com.kyro.ai.ui.screens.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyro.ai.data.repository.KyroRepository
import com.kyro.ai.ui.components.KyroGlowButton
import com.kyro.ai.ui.components.KyroNeonCard
import com.kyro.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun StudioScreen(
    repository: KyroRepository = remember { KyroRepository() }
) {
    var systemPrompt by remember {
        mutableStateOf("You are a specialized enterprise AI logic engine. Output clear, concise answers.")
    }
    var userPrompt by remember { mutableStateOf("") }
    var temperature by remember { mutableStateOf(0.7f) }
    var jsonMode by remember { mutableStateOf(false) }
    var resultText by remember { mutableStateOf("") }
    var modelUsed by remember { mutableStateOf<String?>("gemini-3.8-flash") }
    var isLoading by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    fun runStudioTest() {
        if (userPrompt.isBlank() || isLoading) return
        isLoading = true
        scope.launch {
            val result = repository.studio(systemPrompt, userPrompt, temperature, jsonMode)
            result.onSuccess { res ->
                resultText = res.reply
                modelUsed = res.model ?: "gemini-3.8-flash"
                copied = false
            }.onFailure { err ->
                resultText = "Studio execution failed: ${err.localizedMessage}"
            }
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // System Prompt Card
        KyroNeonCard {
            Text(
                text = "System Instruction (Model Persona & Rules)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = systemPrompt,
                onValueChange = { systemPrompt = it },
                placeholder = { Text("Define how KYRO AI should reason, format, and constrain outputs...", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = NeonPurplePrimary,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                minLines = 2,
                maxLines = 4
            )
        }

        // Hyperparameter Controls
        KyroNeonCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Temperature (Creativity: ${String.format("%.2f", temperature)})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )
            }
            Slider(
                value = temperature,
                onValueChange = { temperature = it },
                valueRange = 0.0f..1.0f,
                colors = SliderDefaults.colors(
                    thumbColor = NeonPurpleLight,
                    activeTrackColor = NeonPurplePrimary,
                    inactiveTrackColor = DarkSurfaceVariant
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // JSON mode toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Structured JSON Output", fontSize = 13.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text(text = "Enforces application/json MIME response", fontSize = 11.sp, color = TextMuted)
                }
                Switch(
                    checked = jsonMode,
                    onCheckedChange = { jsonMode = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = NeonPurplePrimary,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = DarkSurfaceVariant
                    )
                )
            }
        }

        // User Test Prompt Input
        KyroNeonCard {
            Text(
                text = "Input Prompt / Test Payload",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = userPrompt,
                onValueChange = { userPrompt = it },
                placeholder = { Text("Enter prompt to run through KYRO AI Studio playground...", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = NeonPurplePrimary,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                minLines = 4,
                maxLines = 8
            )
        }

        // Action Button
        KyroGlowButton(
            text = "Run Model in AI Studio",
            onClick = { runStudioTest() },
            isLoading = isLoading,
            enabled = userPrompt.isNotBlank(),
            icon = Icons.Default.Tune
        )

        // Output Result
        if (resultText.isNotBlank()) {
            KyroNeonCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NeonPurpleLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Inference Response ($modelUsed)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonPurpleLight
                        )
                    }

                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(resultText))
                            copied = true
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = if (copied) StatusSuccess else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF07050E))
                        .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = resultText,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        fontFamily = if (jsonMode) FontFamily.Monospace else FontFamily.Default,
                        color = Color(0xFFE2E8F0)
                    )
                }
            }
        }
    }
}
