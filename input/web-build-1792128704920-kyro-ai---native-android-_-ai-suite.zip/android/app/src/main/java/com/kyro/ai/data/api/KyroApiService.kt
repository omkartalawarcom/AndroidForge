package com.kyro.ai.data.api

import com.kyro.ai.data.model.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface KyroApiService {
    @POST("api/ai/chat")
    suspend fun sendChatMessage(@Body request: ChatRequest): ChatResponse

    @POST("api/ai/study")
    suspend fun getStudyAssistance(@Body request: StudyRequest): StudyResponse

    @POST("api/ai/writing")
    suspend fun getWritingAssistance(@Body request: WritingRequest): WritingResponse

    @POST("api/ai/code")
    suspend fun getCodeAssistance(@Body request: CodeRequest): CodeResponse

    @POST("api/ai/translate")
    suspend fun translateText(@Body request: TranslateRequest): TranslateResponse

    @POST("api/ai/studio")
    suspend fun executeStudioPrompt(@Body request: StudioRequest): StudioResponse
}

object ApiClient {
    // Configurable backend URL. No Gemini API key is ever embedded into the APK!
    private var baseUrl: String = "https://ais-dev-3z4hslabjhulenr47bbnvb-965942302121.asia-southeast1.run.app/"

    fun setBaseUrl(newUrl: String) {
        baseUrl = if (newUrl.endsWith("/")) newUrl else "$newUrl/"
        retrofitInstance = null
    }

    fun getBaseUrl(): String = baseUrl

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private var retrofitInstance: Retrofit? = null

    val apiService: KyroApiService
        get() {
            if (retrofitInstance == null) {
                retrofitInstance = Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return retrofitInstance!!.create(KyroApiService::class.java)
        }
}
