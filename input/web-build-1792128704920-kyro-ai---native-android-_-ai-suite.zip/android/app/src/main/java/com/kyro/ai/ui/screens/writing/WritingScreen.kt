package com.kyro.ai.ui.screens.writing

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyro.ai.data.repository.KyroRepository
import com.kyro.ai.ui.components.KyroGlowButton
import com.kyro.ai.ui.components.KyroNeonCard
import com.kyro.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun WritingScreen(
    repository: KyroRepository = remember { KyroRepository() }
) {
    var content by remember { mutableStateOf("") }
    var selectedAction by remember { mutableStateOf("essay") }
    var selectedTone by remember { mutableStateOf("Professional") }
    var selectedLength by remember { mutableStateOf("Medium") }
    var resultText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    val actions = listOf(
        "essay" to "Draft Essay",
        "tone" to "Shift Tone",
        "grammar" to "Grammar Polish",
        "paraphrase" to "Paraphrase"
    )

    val tones = listOf("Professional", "Academic", "Persuasive", "Casual", "Visionary")
    val lengths = listOf("Brief", "Medium", "Comprehensive")

    fun generateWriting() {
        if (content.isBlank() || isLoading) return
        isLoading = true
        scope.launch {
            val result = repository.writing(selectedAction, content, selectedTone, selectedLength)
            result.onSuccess {
                resultText = it
                copied = false
            }.onFailure {
                resultText = "Writing generation failed: ${it.localizedMessage}"
            }
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Action Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            actions.forEach { (actionKey, actionTitle) ->
                val isSelected = selectedAction == actionKey
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) NeonPurplePrimary else DarkSurfaceVariant)
                        .border(1.dp, if (isSelected) NeonPurpleLight else DarkBorder, RoundedCornerShape(10.dp))
                        .clickable { selectedAction = actionKey }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = actionTitle,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else TextSecondary,
                        maxLines = 1
                    )
                }
            }
        }

        // Input Box
        KyroNeonCard {
            Text(
                text = "Source Content / Prompt",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                placeholder = {
                    Text(
                        "Paste text to polish or enter topic to compose...",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = NeonPurplePrimary,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                minLines = 4,
                maxLines = 8
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Tone Selector
            Text(text = "Rhetorical Tone", fontSize = 12.sp, color = TextSecondary)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                tones.forEach { tone ->
                    val isSel = selectedTone == tone
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSel) NeonPurpleDark.copy(alpha = 0.5f) else DarkSurface)
                            .border(1.dp, if (isSel) NeonPurpleLight else DarkBorder, RoundedCornerShape(8.dp))
                            .clickable { selectedTone = tone }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tone,
                            fontSize = 10.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSel) TextHighlight else TextMuted
                        )
                    }
                }
            }
        }

        // Generate Button
        KyroGlowButton(
            text = "Generate Masterpiece",
            onClick = { generateWriting() },
            isLoading = isLoading,
            enabled = content.isNotBlank(),
            icon = Icons.Default.EditNote
        )

        // Result Card
        if (resultText.isNotBlank()) {
            KyroNeonCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NeonPurpleLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Polished Composition",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonPurpleLight
                        )
                    }

                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(resultText))
                            copied = true
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = if (copied) StatusSuccess else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = DarkBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = resultText,
                    fontSize = 13.sp,
                    lineHeight = 22.sp,
                    color = TextPrimary
                )
            }
        }
    }
}
