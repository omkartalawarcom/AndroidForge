import React, { useState, useEffect } from 'react';
import {
  Wifi,
  Battery,
  RotateCw,
  Maximize2,
  RefreshCw,
  Smartphone,
  Volume2,
  VolumeX,
  FileCode,
  Sparkles
} from 'lucide-react';
import { AndroidSimulatorApp } from './AndroidSimulatorApp';
import { FeatureTab } from '../types';

interface AndroidDeviceFrameProps {
  initialTab?: FeatureTab;
  onOpenSourceCode?: (filePath?: string) => void;
}

export const AndroidDeviceFrame: React.FC<AndroidDeviceFrameProps> = ({
  initialTab = 'chat',
  onOpenSourceCode
}) => {
  const [currentTime, setCurrentTime] = useState('9:41');
  const [isRotated, setIsRotated] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [scale, setScale] = useState<number>(1);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full">
      {/* Device Control Toolbar */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3 px-4 py-2 rounded-2xl bg-[#140e2d]/80 border border-purple-500/30 backdrop-blur-md shadow-[0_0_20px_rgba(168,85,247,0.15)] max-w-[420px] w-full">
        <div className="flex items-center gap-2 text-xs font-semibold text-purple-200">
          <Smartphone className="w-4 h-4 text-purple-400" />
          <span>Pixel 9 Pro · Jetpack Compose</span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            title={soundEnabled ? 'Mute Haptics/Audio' : 'Unmute Haptics/Audio'}
            className="p-1.5 rounded-lg text-purple-300 hover:text-white hover:bg-purple-900/40 transition"
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-purple-400" /> : <VolumeX className="w-3.5 h-3.5 text-purple-500/50" />}
          </button>

          <button
            onClick={() => setReloadKey(k => k + 1)}
            title="Restart Android App Activity"
            className="p-1.5 rounded-lg text-purple-300 hover:text-white hover:bg-purple-900/40 transition"
          >
            <RefreshCw className="w-3.5 h-3.5 text-purple-400" />
          </button>

          {onOpenSourceCode && (
            <button
              onClick={() => onOpenSourceCode('app/src/main/java/com/kyro/ai/MainActivity.kt')}
              title="Inspect Kotlin Source Code"
              className="flex items-center gap-1 px-2 py-1 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-[11px] font-bold text-purple-200 transition"
            >
              <FileCode className="w-3.5 h-3.5 text-purple-300" />
              <span>Kotlin Code</span>
            </button>
          )}
        </div>
      </div>

      {/* Android Smartphone Chassis */}
      <div
        className={`relative transition-all duration-300 ${
          isRotated ? 'w-[680px] h-[380px]' : 'w-[370px] sm:w-[390px] h-[740px]'
        }`}
        style={{ transform: `scale(${scale})`, transformOrigin: 'top center' }}
      >
        {/* Outer Glow Halo */}
        <div className="absolute -inset-1.5 bg-gradient-to-tr from-purple-600/40 via-fuchsia-600/20 to-purple-900/40 rounded-[52px] blur-md -z-10 animate-pulse" />

        {/* Outer Hardware Bezel */}
        <div className="w-full h-full rounded-[48px] bg-[#1a1436] p-[10px] shadow-[0_20px_60px_rgba(0,0,0,0.8),_0_0_30px_rgba(168,85,247,0.3)] border-2 border-purple-500/40 flex flex-col relative overflow-hidden">
          
          {/* Inner Display Screen */}
          <div className="w-full h-full rounded-[40px] bg-[#0a0715] flex flex-col relative overflow-hidden shadow-inner border border-purple-950">
            
            {/* Android Status Bar */}
            <div className="h-7 w-full bg-[#0a0715] flex items-center justify-between px-6 shrink-0 z-30 select-none">
              <span className="text-[11px] font-bold text-white tracking-wider">
                {currentTime}
              </span>

              {/* Front Camera Punch-hole */}
              <div className="w-3 h-3 rounded-full bg-black border border-purple-900/80 shadow-[inset_0_0_3px_rgba(168,85,247,0.5)]" />

              <div className="flex items-center gap-1.5 text-purple-200">
                <span className="text-[9px] font-extrabold tracking-tighter text-purple-300">5G</span>
                <Wifi className="w-3 h-3 text-purple-300" />
                <Battery className="w-3.5 h-3.5 text-purple-300" />
              </div>
            </div>

            {/* Android App Activity Screen */}
            <div className="flex-1 overflow-hidden relative">
              <AndroidSimulatorApp
                key={reloadKey}
                initialTab={initialTab}
                onViewSourceCode={onOpenSourceCode}
              />
            </div>

            {/* Android Gesture Navigation Bar Pill */}
            <div className="h-4 w-full bg-[#0e0a22] flex items-center justify-center shrink-0 z-30">
              <div className="w-28 h-1 rounded-full bg-purple-400/50 hover:bg-purple-300 transition-all cursor-pointer" />
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
