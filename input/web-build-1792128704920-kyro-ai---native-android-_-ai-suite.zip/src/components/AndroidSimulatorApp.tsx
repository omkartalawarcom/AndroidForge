import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  GraduationCap,
  PenTool,
  Code2,
  Languages,
  Sliders,
  Send,
  Sparkles,
  Copy,
  Check,
  RotateCcw,
  Cpu,
  Layers,
  ArrowRightLeft,
  Settings2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { FeatureTab, ChatMessage } from '../types';

interface AndroidSimulatorAppProps {
  initialTab?: FeatureTab;
  onViewSourceCode?: (filePath: string) => void;
}

export const AndroidSimulatorApp: React.FC<AndroidSimulatorAppProps> = ({
  initialTab = 'chat',
  onViewSourceCode
}) => {
  const [activeTab, setActiveTab] = useState<FeatureTab>(initialTab);

  // Chat State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'model',
      text: 'Hello! I am KYRO AI on Android. How can I accelerate your learning, writing, coding, or translation today?',
      timestamp: Date.now()
    }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Study State
  const [studyTopic, setStudyTopic] = useState('Dijkstra Algorithm');
  const [studyMode, setStudyMode] = useState<'explain' | 'quiz' | 'flashcards' | 'summarize'>('explain');
  const [studyLevel, setStudyLevel] = useState('Intermediate');
  const [studyResult, setStudyResult] = useState('');
  const [isStudyLoading, setIsStudyLoading] = useState(false);

  // Writing State
  const [writingContent, setWritingContent] = useState('Artificial intelligence in modern software architecture');
  const [writingAction, setWritingAction] = useState<'essay' | 'tone' | 'grammar' | 'paraphrase'>('essay');
  const [writingTone, setWritingTone] = useState('Professional & Visionary');
  const [writingResult, setWritingResult] = useState('');
  const [isWritingLoading, setIsWritingLoading] = useState(false);

  // Code State
  const [codePrompt, setCodePrompt] = useState('fun calculateFibonacci(n: Int): Long {\n  // Jetpack Compose optimized\n}');
  const [codeAction, setCodeAction] = useState<'generate' | 'debug' | 'refactor' | 'explain'>('generate');
  const [codeLang, setCodeLang] = useState('Kotlin');
  const [codeResult, setCodeResult] = useState('');
  const [isCodeLoading, setIsCodeLoading] = useState(false);

  // Translator State
  const [transSource, setTransSource] = useState('Where is the nearest innovation hub in Tokyo?');
  const [sourceLang, setSourceLang] = useState('English');
  const [targetLang, setTargetLang] = useState('Japanese');
  const [transFormality, setTransFormality] = useState('Polite / Formal');
  const [transResult, setTransResult] = useState('');
  const [isTransLoading, setIsTransLoading] = useState(false);

  // Studio State
  const [studioSystem, setStudioSystem] = useState('You are an expert systems engineer. Answer concisely with bulleted specifications.');
  const [studioPrompt, setStudioPrompt] = useState('Design a low-latency caching architecture for mobile clients.');
  const [studioTemp, setStudioTemp] = useState(0.7);
  const [studioJson, setStudioJson] = useState(false);
  const [studioResult, setStudioResult] = useState('');
  const [isStudioLoading, setIsStudioLoading] = useState(false);

  // Copy Feedback
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isChatLoading]);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // 1. Send Chat Message
  const handleSendChat = async () => {
    if (!chatInput.trim() || isChatLoading) return;
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: chatInput,
      timestamp: Date.now()
    };
    const updated = [...chatMessages, userMsg];
    setChatMessages(updated);
    setChatInput('');
    setIsChatLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updated.map(m => ({ role: m.role, text: m.text }))
        })
      });
      const data = await res.json();
      if (data.reply) {
        setChatMessages(prev => [
          ...prev,
          {
            id: (Date.now() + 1).toString(),
            role: 'model',
            text: data.reply,
            timestamp: Date.now()
          }
        ]);
      } else {
        throw new Error(data.error || 'Failed response');
      }
    } catch (err: any) {
      setChatMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'model',
          text: `KYRO Connection Notice: ${err.message || 'Server unreachable'}. Verify your connection.`,
          timestamp: Date.now()
        }
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // 2. Study Assistant Call
  const handleRunStudy = async () => {
    if (!studyTopic.trim() || isStudyLoading) return;
    setIsStudyLoading(true);
    setStudyResult('');
    try {
      const res = await fetch('/api/ai/study', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: studyMode,
          topic: studyTopic,
          level: studyLevel
        })
      });
      const data = await res.json();
      setStudyResult(data.reply || data.error || 'No response');
    } catch (err: any) {
      setStudyResult(`Error: ${err.message}`);
    } finally {
      setIsStudyLoading(false);
    }
  };

  // 3. Writing Assistant Call
  const handleRunWriting = async () => {
    if (!writingContent.trim() || isWritingLoading) return;
    setIsWritingLoading(true);
    setWritingResult('');
    try {
      const res = await fetch('/api/ai/writing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: writingAction,
          content: writingContent,
          tone: writingTone
        })
      });
      const data = await res.json();
      setWritingResult(data.reply || data.error || 'No response');
    } catch (err: any) {
      setWritingResult(`Error: ${err.message}`);
    } finally {
      setIsWritingLoading(false);
    }
  };

  // 4. Code Assistant Call
  const handleRunCode = async () => {
    if (!codePrompt.trim() || isCodeLoading) return;
    setIsCodeLoading(true);
    setCodeResult('');
    try {
      const res = await fetch('/api/ai/code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: codeAction,
          codeOrPrompt: codePrompt,
          language: codeLang
        })
      });
      const data = await res.json();
      setCodeResult(data.reply || data.error || 'No response');
    } catch (err: any) {
      setCodeResult(`Error: ${err.message}`);
    } finally {
      setIsCodeLoading(false);
    }
  };

  // 5. Translator Call
  const handleRunTranslate = async () => {
    if (!transSource.trim() || isTransLoading) return;
    setIsTransLoading(true);
    setTransResult('');
    try {
      const res = await fetch('/api/ai/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: transSource,
          sourceLang,
          targetLang,
          formality: transFormality
        })
      });
      const data = await res.json();
      setTransResult(data.reply || data.error || 'No response');
    } catch (err: any) {
      setTransResult(`Error: ${err.message}`);
    } finally {
      setIsTransLoading(false);
    }
  };

  // 6. Studio Playground Call
  const handleRunStudio = async () => {
    if (!studioPrompt.trim() || isStudioLoading) return;
    setIsStudioLoading(true);
    setStudioResult('');
    try {
      const res = await fetch('/api/ai/studio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemPrompt: studioSystem,
          userPrompt: studioPrompt,
          temperature: studioTemp,
          jsonMode: studioJson
        })
      });
      const data = await res.json();
      setStudioResult(data.reply || data.error || 'No response');
    } catch (err: any) {
      setStudioResult(`Error: ${err.message}`);
    } finally {
      setIsStudioLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0715] text-purple-100 font-sans select-none overflow-hidden">
      {/* Jetpack Compose Header Bar */}
      <div className="px-4 py-2.5 bg-[#0f0b21]/90 backdrop-blur-md border-b border-purple-500/20 flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-fuchsia-500 flex items-center justify-center font-black text-white text-base shadow-[0_0_12px_rgba(168,85,247,0.5)]">
            K
          </div>
          <div>
            <div className="flex items-center gap-1.5 leading-none">
              <span className="font-extrabold text-sm tracking-wide text-white">KYRO</span>
              <span className="font-bold text-sm text-purple-400">AI</span>
            </div>
            <span className="text-[10px] text-purple-300/70 capitalize font-medium">
              {activeTab === 'chat' && 'AI Conversation'}
              {activeTab === 'study' && 'Study Assistant'}
              {activeTab === 'writing' && 'Writing Assistant'}
              {activeTab === 'code' && 'Code Assistant'}
              {activeTab === 'translator' && 'Translator'}
              {activeTab === 'studio' && 'AI Studio (Pro)'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <div className="px-2 py-0.5 rounded-full bg-purple-950/80 border border-purple-500/30 flex items-center gap-1 text-[9px] font-semibold text-purple-200">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span>GEMINI 3.8</span>
          </div>
        </div>
      </div>

      {/* Main Screen Content Area */}
      <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3">
        {/* ================= SCREEN 1: AI CHAT ================= */}
        {activeTab === 'chat' && (
          <div className="flex flex-col h-full space-y-3">
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 min-h-[320px]">
              {chatMessages.map(msg => {
                const isUser = msg.role === 'user';
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isUser ? 'justify-end' : 'justify-start'} animate-in fade-in duration-200`}
                  >
                    {!isUser && (
                      <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-purple-600 to-fuchsia-500 flex items-center justify-center text-white text-[10px] mr-1.5 mt-1 shrink-0 shadow-[0_0_8px_rgba(168,85,247,0.4)]">
                        <Sparkles className="w-3.5 h-3.5" />
                      </div>
                    )}
                    <div
                      className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed ${
                        isUser
                          ? 'bg-gradient-to-r from-purple-700 to-purple-600 text-white rounded-br-xs shadow-[0_0_15px_rgba(147,51,234,0.3)]'
                          : 'bg-[#150f2e] text-purple-100 border border-purple-500/25 rounded-bl-xs shadow-sm'
                      }`}
                    >
                      <div className="whitespace-pre-wrap">{msg.text}</div>
                    </div>
                  </div>
                );
              })}

              {isChatLoading && (
                <div className="flex items-center gap-2 text-purple-400 text-xs py-1">
                  <div className="w-4 h-4 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
                  <span>KYRO is generating response...</span>
                </div>
              )}
              <div ref={chatBottomRef} />
            </div>

            {/* Quick Prompts */}
            {chatMessages.length <= 2 && (
              <div className="flex gap-1.5 overflow-x-auto pb-1 text-[10px]">
                {['Explain Quantum Supremacy', 'Compose Neon Button in Kotlin', 'Design System Ideas'].map((qp, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setChatInput(qp);
                    }}
                    className="whitespace-nowrap px-2.5 py-1 rounded-full bg-purple-950/60 border border-purple-500/30 text-purple-300 hover:border-purple-400 transition"
                  >
                    {qp}
                  </button>
                ))}
              </div>
            )}

            {/* Input Bar */}
            <div className="pt-1">
              <div className="flex items-center gap-1.5 bg-[#140e2b] border border-purple-500/30 rounded-2xl p-1.5 shadow-[0_0_12px_rgba(168,85,247,0.15)] focus-within:border-purple-400 transition">
                <input
                  type="text"
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSendChat()}
                  placeholder="Ask KYRO AI anything..."
                  className="flex-1 bg-transparent px-2.5 py-1 text-xs text-white placeholder-purple-400/50 outline-none"
                />
                <button
                  onClick={handleSendChat}
                  disabled={!chatInput.trim() || isChatLoading}
                  className="w-8 h-8 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-500 flex items-center justify-center text-white disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_0_10px_rgba(168,85,247,0.4)] active:scale-95 transition"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ================= SCREEN 2: STUDY ASSISTANT ================= */}
        {activeTab === 'study' && (
          <div className="space-y-3">
            {/* Mode Tabs */}
            <div className="grid grid-cols-4 gap-1">
              {[
                { id: 'explain', label: 'Explain' },
                { id: 'quiz', label: 'Quiz' },
                { id: 'flashcards', label: 'Cards' },
                { id: 'summarize', label: 'Summary' }
              ].map(m => (
                <button
                  key={m.id}
                  onClick={() => setStudyMode(m.id as any)}
                  className={`py-1.5 px-1 rounded-lg text-[10px] font-semibold transition text-center ${
                    studyMode === m.id
                      ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(168,85,247,0.4)] border border-purple-400'
                      : 'bg-purple-950/40 text-purple-300 border border-purple-500/20 hover:border-purple-500/40'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            {/* Input Card */}
            <div className="p-3 rounded-xl bg-[#140e2b] border border-purple-500/25 space-y-2">
              <label className="text-[11px] font-bold text-purple-200">Learning Subject / Concept</label>
              <textarea
                value={studyTopic}
                onChange={e => setStudyTopic(e.target.value)}
                rows={2}
                placeholder="e.g. Mitochondria ATP cycle, Graph Algorithms, Supply and Demand..."
                className="w-full bg-[#0d091e] border border-purple-500/30 rounded-lg p-2 text-xs text-white placeholder-purple-400/40 outline-none focus:border-purple-400"
              />

              <div className="flex items-center justify-between pt-1">
                <span className="text-[10px] text-purple-300">Level:</span>
                <div className="flex gap-1 text-[9px]">
                  {['Beginner', 'Intermediate', 'Advanced'].map(lvl => (
                    <button
                      key={lvl}
                      onClick={() => setStudyLevel(lvl)}
                      className={`px-2 py-0.5 rounded ${
                        studyLevel === lvl
                          ? 'bg-purple-700 text-white font-bold'
                          : 'bg-purple-950/60 text-purple-400'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Button */}
            <button
              onClick={handleRunStudy}
              disabled={!studyTopic.trim() || isStudyLoading}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white text-xs font-bold shadow-[0_0_15px_rgba(168,85,247,0.35)] flex items-center justify-center gap-1.5 active:scale-98 transition disabled:opacity-40"
            >
              {isStudyLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>Generate Accelerated Study Aid</span>
                </>
              )}
            </button>

            {/* Results Output */}
            {studyResult && (
              <div className="p-3 rounded-xl bg-[#140e2b] border border-purple-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-purple-300">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                    Study Material
                  </span>
                  <button
                    onClick={() => copyToClipboard(studyResult, 'study')}
                    className="p-1 text-purple-400 hover:text-white"
                  >
                    {copiedKey === 'study' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="text-xs text-purple-100 whitespace-pre-wrap leading-relaxed max-h-56 overflow-y-auto">
                  {studyResult}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= SCREEN 3: WRITING ASSISTANT ================= */}
        {activeTab === 'writing' && (
          <div className="space-y-3">
            {/* Action Selector */}
            <div className="grid grid-cols-4 gap-1">
              {[
                { id: 'essay', label: 'Essay' },
                { id: 'tone', label: 'Tone' },
                { id: 'grammar', label: 'Polish' },
                { id: 'paraphrase', label: 'Paraphrase' }
              ].map(a => (
                <button
                  key={a.id}
                  onClick={() => setWritingAction(a.id as any)}
                  className={`py-1.5 px-1 rounded-lg text-[10px] font-semibold transition text-center ${
                    writingAction === a.id
                      ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(168,85,247,0.4)] border border-purple-400'
                      : 'bg-purple-950/40 text-purple-300 border border-purple-500/20'
                  }`}
                >
                  {a.label}
                </button>
              ))}
            </div>

            {/* Input Box */}
            <div className="p-3 rounded-xl bg-[#140e2b] border border-purple-500/25 space-y-2">
              <label className="text-[11px] font-bold text-purple-200">Draft or Outline</label>
              <textarea
                value={writingContent}
                onChange={e => setWritingContent(e.target.value)}
                rows={3}
                placeholder="Enter raw text to polish or outline a narrative..."
                className="w-full bg-[#0d091e] border border-purple-500/30 rounded-lg p-2 text-xs text-white placeholder-purple-400/40 outline-none focus:border-purple-400"
              />

              <div className="flex items-center justify-between pt-1">
                <span className="text-[10px] text-purple-300">Tone:</span>
                <select
                  value={writingTone}
                  onChange={e => setWritingTone(e.target.value)}
                  className="bg-[#0d091e] border border-purple-500/30 rounded px-2 py-0.5 text-[10px] text-purple-200 outline-none"
                >
                  <option value="Professional & Visionary">Professional</option>
                  <option value="Academic & Rigorous">Academic</option>
                  <option value="Persuasive & Executive">Persuasive</option>
                  <option value="Casual & Engaging">Casual</option>
                </select>
              </div>
            </div>

            {/* Action Button */}
            <button
              onClick={handleRunWriting}
              disabled={!writingContent.trim() || isWritingLoading}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white text-xs font-bold shadow-[0_0_15px_rgba(168,85,247,0.35)] flex items-center justify-center gap-1.5 active:scale-98 transition disabled:opacity-40"
            >
              {isWritingLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <PenTool className="w-3.5 h-3.5" />
                  <span>Generate Polished Writing</span>
                </>
              )}
            </button>

            {/* Output */}
            {writingResult && (
              <div className="p-3 rounded-xl bg-[#140e2b] border border-purple-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-purple-300">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                    Polished Output
                  </span>
                  <button
                    onClick={() => copyToClipboard(writingResult, 'writing')}
                    className="p-1 text-purple-400 hover:text-white"
                  >
                    {copiedKey === 'writing' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="text-xs text-purple-100 whitespace-pre-wrap leading-relaxed max-h-56 overflow-y-auto">
                  {writingResult}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= SCREEN 4: CODE ASSISTANT ================= */}
        {activeTab === 'code' && (
          <div className="space-y-3">
            {/* Language Pills */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 text-[10px]">
              {['Kotlin', 'TypeScript', 'Python', 'Rust', 'Swift', 'Java'].map(lang => (
                <button
                  key={lang}
                  onClick={() => setCodeLang(lang)}
                  className={`px-2.5 py-1 rounded-lg font-mono font-medium transition ${
                    codeLang === lang
                      ? 'bg-purple-600 text-white border border-purple-300 shadow-[0_0_8px_rgba(168,85,247,0.5)]'
                      : 'bg-purple-950/40 text-purple-300 border border-purple-500/20'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>

            {/* Action Bar */}
            <div className="grid grid-cols-4 gap-1">
              {[
                { id: 'generate', label: 'Generate' },
                { id: 'debug', label: 'Debug' },
                { id: 'refactor', label: 'Refactor' },
                { id: 'explain', label: 'Explain' }
              ].map(a => (
                <button
                  key={a.id}
                  onClick={() => setCodeAction(a.id as any)}
                  className={`py-1 rounded text-[10px] font-semibold transition ${
                    codeAction === a.id
                      ? 'bg-purple-700 text-white font-bold'
                      : 'bg-purple-950/30 text-purple-400'
                  }`}
                >
                  {a.label}
                </button>
              ))}
            </div>

            {/* Code Input */}
            <div className="p-3 rounded-xl bg-[#140e2b] border border-purple-500/25 space-y-1.5">
              <div className="flex justify-between items-center text-[10px] text-purple-300">
                <span className="font-bold">Specification or Code Snippet</span>
                <span className="text-cyan-400 font-mono">{codeLang}</span>
              </div>
              <textarea
                value={codePrompt}
                onChange={e => setCodePrompt(e.target.value)}
                rows={4}
                className="w-full bg-[#090616] border border-purple-500/30 rounded-lg p-2 font-mono text-[11px] text-purple-100 placeholder-purple-500/40 outline-none focus:border-purple-400"
              />
            </div>

            {/* Action Button */}
            <button
              onClick={handleRunCode}
              disabled={!codePrompt.trim() || isCodeLoading}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white text-xs font-bold shadow-[0_0_15px_rgba(168,85,247,0.35)] flex items-center justify-center gap-1.5 active:scale-98 transition disabled:opacity-40"
            >
              {isCodeLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Code2 className="w-3.5 h-3.5" />
                  <span>Execute Code Engine</span>
                </>
              )}
            </button>

            {/* Code Result */}
            {codeResult && (
              <div className="p-3 rounded-xl bg-[#090616] border border-purple-500/40 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-purple-300">
                  <span className="text-cyan-400 font-mono text-[11px]">Output // {codeLang}</span>
                  <button
                    onClick={() => copyToClipboard(codeResult, 'code')}
                    className="p-1 text-purple-400 hover:text-white"
                  >
                    {copiedKey === 'code' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="text-[11px] font-mono text-purple-100 whitespace-pre-wrap leading-relaxed max-h-56 overflow-y-auto bg-black/40 p-2 rounded">
                  {codeResult}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= SCREEN 5: TRANSLATOR ================= */}
        {activeTab === 'translator' && (
          <div className="space-y-3">
            {/* Language Swap Row */}
            <div className="flex items-center gap-2">
              <div className="flex-1 p-2 rounded-xl bg-[#140e2b] border border-purple-500/30 text-center font-bold text-xs text-purple-200">
                {sourceLang}
              </div>
              <button
                onClick={() => {
                  const t = sourceLang;
                  setSourceLang(targetLang);
                  setTargetLang(t);
                  if (transResult) {
                    setTransSource(transResult);
                    setTransResult('');
                  }
                }}
                className="w-8 h-8 rounded-full bg-purple-900/60 border border-purple-400/40 flex items-center justify-center text-purple-300 hover:text-white hover:border-purple-300 transition"
              >
                <ArrowRightLeft className="w-3.5 h-3.5" />
              </button>
              <div className="flex-1 p-2 rounded-xl bg-[#140e2b] border border-purple-500/30 text-center font-bold text-xs text-purple-300">
                {targetLang}
              </div>
            </div>

            {/* Quick Target Langs */}
            <div className="flex gap-1 overflow-x-auto text-[10px]">
              {['Spanish', 'Japanese', 'French', 'German', 'Mandarin', 'Arabic'].map(l => (
                <button
                  key={l}
                  onClick={() => setTargetLang(l)}
                  className={`px-2 py-0.5 rounded ${
                    targetLang === l ? 'bg-purple-600 text-white font-bold' : 'bg-purple-950/40 text-purple-300'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>

            {/* Source Input */}
            <div className="p-3 rounded-xl bg-[#140e2b] border border-purple-500/25 space-y-2">
              <label className="text-[11px] font-bold text-purple-200">Text to Translate</label>
              <textarea
                value={transSource}
                onChange={e => setTransSource(e.target.value)}
                rows={3}
                placeholder="Type or paste text..."
                className="w-full bg-[#0d091e] border border-purple-500/30 rounded-lg p-2 text-xs text-white placeholder-purple-400/40 outline-none focus:border-purple-400"
              />

              <div className="flex items-center justify-between text-[10px] text-purple-300 pt-1">
                <span>Formality:</span>
                <div className="flex gap-1 text-[9px]">
                  {['Natural', 'Casual', 'Polite / Formal'].map(f => (
                    <button
                      key={f}
                      onClick={() => setTransFormality(f)}
                      className={`px-2 py-0.5 rounded ${
                        transFormality === f ? 'bg-purple-700 text-white' : 'bg-purple-950/60 text-purple-400'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Button */}
            <button
              onClick={handleRunTranslate}
              disabled={!transSource.trim() || isTransLoading}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white text-xs font-bold shadow-[0_0_15px_rgba(168,85,247,0.35)] flex items-center justify-center gap-1.5 active:scale-98 transition disabled:opacity-40"
            >
              {isTransLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Languages className="w-3.5 h-3.5" />
                  <span>Translate with Nuance Notes</span>
                </>
              )}
            </button>

            {/* Output */}
            {transResult && (
              <div className="p-3 rounded-xl bg-[#140e2b] border border-purple-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-purple-300">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                    Translation Output
                  </span>
                  <button
                    onClick={() => copyToClipboard(transResult, 'translate')}
                    className="p-1 text-purple-400 hover:text-white"
                  >
                    {copiedKey === 'translate' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="text-xs text-purple-100 whitespace-pre-wrap leading-relaxed max-h-56 overflow-y-auto">
                  {transResult}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= SCREEN 6: AI STUDIO ================= */}
        {activeTab === 'studio' && (
          <div className="space-y-3">
            {/* System Instruction */}
            <div className="p-3 rounded-xl bg-[#140e2b] border border-purple-500/25 space-y-1.5">
              <label className="text-[11px] font-bold text-purple-200">System Instruction</label>
              <textarea
                value={studioSystem}
                onChange={e => setStudioSystem(e.target.value)}
                rows={2}
                className="w-full bg-[#0d091e] border border-purple-500/30 rounded-lg p-2 text-[11px] text-white placeholder-purple-400/40 outline-none focus:border-purple-400"
              />
            </div>

            {/* Prompt */}
            <div className="p-3 rounded-xl bg-[#140e2b] border border-purple-500/25 space-y-1.5">
              <label className="text-[11px] font-bold text-purple-200">User Test Prompt</label>
              <textarea
                value={studioPrompt}
                onChange={e => setStudioPrompt(e.target.value)}
                rows={2}
                className="w-full bg-[#0d091e] border border-purple-500/30 rounded-lg p-2 text-xs text-white placeholder-purple-400/40 outline-none focus:border-purple-400"
              />
            </div>

            {/* Tuning Controls */}
            <div className="p-2.5 rounded-xl bg-[#140e2b] border border-purple-500/25 space-y-2 text-[11px]">
              <div className="flex items-center justify-between text-purple-300">
                <span>Temperature (Creativity)</span>
                <span className="font-mono text-cyan-400 font-bold">{studioTemp}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={studioTemp}
                onChange={e => setStudioTemp(parseFloat(e.target.value))}
                className="w-full accent-purple-500"
              />

              <div className="flex items-center justify-between pt-1">
                <span className="text-purple-300">JSON Output Mode</span>
                <input
                  type="checkbox"
                  checked={studioJson}
                  onChange={e => setStudioJson(e.target.checked)}
                  className="w-4 h-4 accent-purple-500 rounded"
                />
              </div>
            </div>

            {/* Action Button */}
            <button
              onClick={handleRunStudio}
              disabled={!studioPrompt.trim() || isStudioLoading}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white text-xs font-bold shadow-[0_0_15px_rgba(168,85,247,0.35)] flex items-center justify-center gap-1.5 active:scale-98 transition disabled:opacity-40"
            >
              {isStudioLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Run Model in AI Studio</span>
                </>
              )}
            </button>

            {/* Output */}
            {studioResult && (
              <div className="p-3 rounded-xl bg-[#090616] border border-purple-500/40 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-purple-300">
                  <span className="text-cyan-400 font-mono text-[10px]">Inference Response</span>
                  <button
                    onClick={() => copyToClipboard(studioResult, 'studio')}
                    className="p-1 text-purple-400 hover:text-white"
                  >
                    {copiedKey === 'studio' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="text-[11px] font-mono text-purple-100 whitespace-pre-wrap leading-relaxed max-h-56 overflow-y-auto bg-black/40 p-2 rounded">
                  {studioResult}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Jetpack Compose Bottom Navigation Bar */}
      <div className="px-2 py-1.5 bg-[#0e0a22] border-t border-purple-500/25 flex items-center justify-around shrink-0 z-10">
        {[
          { id: 'chat', label: 'Chat', icon: MessageSquare },
          { id: 'study', label: 'Study', icon: GraduationCap },
          { id: 'writing', label: 'Writing', icon: PenTool },
          { id: 'code', label: 'Code', icon: Code2 },
          { id: 'translator', label: 'Translate', icon: Languages },
          { id: 'studio', label: 'Studio', icon: Sliders }
        ].map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as FeatureTab)}
              className="flex flex-col items-center gap-0.5 px-2 py-1 rounded-xl transition group"
            >
              <div
                className={`w-9 h-6 rounded-full flex items-center justify-center transition-all ${
                  isActive
                    ? 'bg-purple-600/30 text-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                    : 'text-purple-400/60 group-hover:text-purple-300'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-purple-300 stroke-[2.5]' : ''}`} />
              </div>
              <span
                className={`text-[9px] tracking-tight font-medium ${
                  isActive ? 'text-purple-200 font-bold' : 'text-purple-400/60'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
