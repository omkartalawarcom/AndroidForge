import React, { useState } from 'react';
import {
  MessageSquare,
  GraduationCap,
  PenTool,
  Code2,
  Languages,
  Sliders,
  Sparkles,
  Send,
  Copy,
  Check,
  ChevronRight,
  ShieldCheck,
  Zap,
  ArrowRight
} from 'lucide-react';
import { FeatureTab } from '../types';

interface WebDashboardProps {
  onSwitchToMobile: (tab: FeatureTab) => void;
  onOpenCodeExplorer: () => void;
}

export const WebDashboard: React.FC<WebDashboardProps> = ({
  onSwitchToMobile,
  onOpenCodeExplorer
}) => {
  const [activeTab, setActiveTab] = useState<FeatureTab>('chat');

  // Interactive Desktop Chat State
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'model'; text: string }>>([
    {
      role: 'model',
      text: 'Welcome to KYRO AI. What would you like to build, analyze, study, or compose today?'
    }
  ]);
  const [inputVal, setInputVal] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleSend = async () => {
    if (!inputVal.trim() || loading) return;
    const newMsgs = [...messages, { role: 'user' as const, text: inputVal }];
    setMessages(newMsgs);
    setInputVal('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: newMsgs })
      });
      const data = await res.json();
      setMessages([...newMsgs, { role: 'model', text: data.reply || 'No response' }]);
    } catch (e: any) {
      setMessages([...newMsgs, { role: 'model', text: `Error: ${e.message}` }]);
    } finally {
      setLoading(false);
    }
  };

  const copyText = (txt: string, idx: number) => {
    navigator.clipboard.writeText(txt);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const featureCards = [
    {
      id: 'chat' as FeatureTab,
      title: 'AI Chat',
      desc: 'Context-aware intelligence with real-time reasoning and multi-turn conversational memory.',
      icon: MessageSquare,
      badge: 'Core Engine'
    },
    {
      id: 'study' as FeatureTab,
      title: 'Study Assistant',
      desc: 'Active recall, interactive quizzes, flashcards, and pedagogical explanations for complex topics.',
      icon: GraduationCap,
      badge: 'Learning'
    },
    {
      id: 'writing' as FeatureTab,
      title: 'Writing Assistant',
      desc: 'Rhetorical tone shifting, academic essays, concise executive summaries, and grammar polish.',
      icon: PenTool,
      badge: 'Creative'
    },
    {
      id: 'code' as FeatureTab,
      title: 'Code Assistant',
      desc: 'Polyglot code generation (Kotlin, Python, TS), AST refactoring, bug fixes, and algorithmic proofs.',
      icon: Code2,
      badge: 'Developer'
    },
    {
      id: 'translator' as FeatureTab,
      title: 'Translator',
      desc: 'Nuanced multilingual translation with formality toggles, phonetic pronunciation, and cultural context.',
      icon: Languages,
      badge: 'Linguistics'
    },
    {
      id: 'studio' as FeatureTab,
      title: 'AI Studio',
      desc: 'Prompt engineering sandbox with temperature control, custom system instructions, and JSON schemas.',
      icon: Sliders,
      badge: 'Pro Testing'
    }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 py-6">
      {/* Hero Section matching KYRO AI Website */}
      <div className="relative rounded-3xl p-8 sm:p-12 overflow-hidden bg-gradient-to-br from-[#160e33] via-[#0f0923] to-[#070512] border border-purple-500/30 shadow-[0_0_50px_rgba(168,85,247,0.2)]">
        {/* Neon Background Radial Glows */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-80 h-80 bg-fuchsia-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-500/40 text-xs font-semibold text-purple-300">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Next-Gen Intelligence Suite · Android & Web</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white leading-tight">
            KYRO <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-fuchsia-400 to-purple-300">AI</span>
          </h1>

          <p className="text-base sm:text-lg text-purple-200/80 leading-relaxed">
            The ultimate AI suite designed for developers, students, and professionals. Native Android project powered by Kotlin & Jetpack Compose, backed by enterprise-grade server-side Gemini intelligence.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSwitchToMobile('chat')}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-purple-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-bold text-sm shadow-[0_0_25px_rgba(168,85,247,0.4)] flex items-center gap-2 transition active:scale-95"
            >
              <span>Launch Android Mobile Simulator</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenCodeExplorer}
              className="px-6 py-3 rounded-xl bg-[#1d1540] hover:bg-[#251b52] border border-purple-500/40 text-purple-200 font-bold text-sm transition flex items-center gap-2"
            >
              <Code2 className="w-4 h-4 text-purple-400" />
              <span>Explore Kotlin & Gradle Code</span>
            </button>
          </div>
        </div>
      </div>

      {/* Feature Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-black text-white">Core Capabilities</h2>
            <p className="text-xs text-purple-300/70">
              All 6 features available in both native Android (Kotlin Compose) and the web companion.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {featureCards.map(fc => {
            const Icon = fc.icon;
            return (
              <div
                key={fc.id}
                onClick={() => onSwitchToMobile(fc.id)}
                className="group p-5 rounded-2xl bg-[#120d2a]/90 hover:bg-[#181138] border border-purple-500/20 hover:border-purple-400/60 transition-all duration-300 cursor-pointer shadow-[0_4px_20px_rgba(0,0,0,0.4)] hover:shadow-[0_0_30px_rgba(168,85,247,0.25)] flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600/40 to-fuchsia-600/40 border border-purple-500/30 flex items-center justify-center text-purple-300 group-hover:scale-105 transition">
                      <Icon className="w-5 h-5 text-purple-300" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-950/80 border border-purple-500/30 text-purple-300">
                      {fc.badge}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition">
                    {fc.title}
                  </h3>
                  <p className="text-xs text-purple-200/70 mt-1 leading-relaxed">
                    {fc.desc}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-purple-500/15 flex items-center justify-between text-xs font-semibold text-purple-400 group-hover:text-purple-300">
                  <span>Open on Android</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Live Web AI Console */}
      <div className="rounded-2xl p-6 bg-[#0e0922] border border-purple-500/30 space-y-4 shadow-[0_0_30px_rgba(168,85,247,0.1)]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-purple-400" />
            <h3 className="text-lg font-bold text-white">Live Web Playground</h3>
          </div>
          <span className="text-xs text-purple-300 font-mono">
            Model: gemini-3.8-flash (Server Secure Proxy)
          </span>
        </div>

        {/* Message Stream */}
        <div className="space-y-3 max-h-72 overflow-y-auto p-4 rounded-xl bg-[#090616] border border-purple-500/20">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-purple-700 text-white'
                    : 'bg-[#150f2f] text-purple-100 border border-purple-500/25'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="whitespace-pre-wrap">{m.text}</div>
                  {m.role === 'model' && (
                    <button
                      onClick={() => copyText(m.text, idx)}
                      className="p-1 text-purple-400 hover:text-white"
                    >
                      {copiedIndex === idx ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-purple-400 text-xs py-2">
              <div className="w-4 h-4 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
              <span>KYRO is generating...</span>
            </div>
          )}
        </div>

        {/* Console Input */}
        <div className="flex gap-2">
          <input
            type="text"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder="Type a query to test server-side Gemini integration..."
            className="flex-1 px-4 py-2.5 rounded-xl bg-[#140e2b] border border-purple-500/30 text-xs text-white placeholder-purple-400/40 outline-none focus:border-purple-400 transition"
          />
          <button
            onClick={handleSend}
            disabled={!inputVal.trim() || loading}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 transition disabled:opacity-40"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send</span>
          </button>
        </div>
      </div>
    </div>
  );
};
