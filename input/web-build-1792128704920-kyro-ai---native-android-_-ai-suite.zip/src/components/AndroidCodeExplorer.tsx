import React, { useState } from 'react';
import {
  FolderTree,
  FileCode,
  Download,
  Copy,
  Check,
  ExternalLink,
  Terminal,
  ShieldCheck,
  Sparkles,
  Layers,
  Code2
} from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES, AndroidFile } from '../androidProjectData';

interface AndroidCodeExplorerProps {
  selectedFileInitial?: string;
}

export const AndroidCodeExplorer: React.FC<AndroidCodeExplorerProps> = ({
  selectedFileInitial
}) => {
  const [selectedPath, setSelectedPath] = useState<string>(
    selectedFileInitial || 'app/src/main/java/com/kyro/ai/MainActivity.kt'
  );
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [zipSuccess, setZipSuccess] = useState(false);

  const currentFile =
    ANDROID_PROJECT_FILES.find(f => f.path === selectedPath) || ANDROID_PROJECT_FILES[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const rootFolder = zip.folder('kyro-ai-android');

      // Add all project files
      ANDROID_PROJECT_FILES.forEach(file => {
        rootFolder?.file(file.path, file.content);
      });

      // Add gradle wrapper properties
      rootFolder?.file(
        'gradle/wrapper/gradle-wrapper.properties',
        `distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-8.10.2-bin.zip\nzipStoreBase=GRADLE_USER_HOME\nzipStorePath=wrapper/dists\n`
      );

      // Add root README
      rootFolder?.file(
        'QUICK_START.md',
        `# KYRO AI Android Project Quickstart\n\n1. Open Android Studio (Ladybug / Koala).\n2. Select "Open" and choose this unzipped folder.\n3. Sync Gradle and run on device or emulator.\n4. No client-side Gemini API keys required (handled via backend proxy).\n`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'kyro-ai-android-project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setZipSuccess(true);
      setTimeout(() => setZipSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to create zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* Top Banner & Download Button */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#170f36] to-[#120a28] border border-purple-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-[0_0_25px_rgba(168,85,247,0.15)]">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-purple-950 border border-purple-500/40 text-purple-300 font-bold text-xs">
              KOTLIN 2.0 + COMPOSE
            </span>
            <span className="flex items-center gap-1 text-xs text-green-400 font-medium">
              <ShieldCheck className="w-3.5 h-3.5" />
              Zero Client-Side Key Exposure
            </span>
          </div>
          <h2 className="text-xl font-extrabold text-white mt-1">
            KYRO AI Native Android Project Hub
          </h2>
          <p className="text-xs text-purple-300/80 mt-0.5">
            Production-ready Gradle & Jetpack Compose codebase with clean architecture, Retrofit networking, and purple neon theme.
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-purple-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-bold text-xs shadow-[0_0_20px_rgba(168,85,247,0.4)] flex items-center gap-2 active:scale-95 transition shrink-0"
        >
          {isZipping ? (
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : zipSuccess ? (
            <>
              <Check className="w-4 h-4 text-green-300" />
              <span>Downloaded!</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              <span>Download Project (.ZIP)</span>
            </>
          )}
        </button>
      </div>

      {/* Main Split: File Tree on Left, Code Viewer on Right */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-4 min-h-[550px]">
        {/* Left: Project File Tree */}
        <div className="md:col-span-4 rounded-2xl bg-[#110c28]/90 border border-purple-500/25 p-3.5 flex flex-col space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-purple-500/20">
            <div className="flex items-center gap-2 text-xs font-bold text-purple-200">
              <FolderTree className="w-4 h-4 text-purple-400" />
              <span>Project Structure</span>
            </div>
            <span className="text-[10px] text-purple-400/70 font-mono">
              {ANDROID_PROJECT_FILES.length} files
            </span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-1 pr-1 font-mono text-xs">
            {ANDROID_PROJECT_FILES.map(file => {
              const isSelected = file.path === selectedPath;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedPath(file.path)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 transition ${
                    isSelected
                      ? 'bg-purple-600/30 text-white border border-purple-500/50 shadow-[0_0_10px_rgba(168,85,247,0.2)]'
                      : 'text-purple-300/80 hover:bg-purple-950/40 hover:text-purple-200'
                  }`}
                >
                  <FileCode className={`w-3.5 h-3.5 ${isSelected ? 'text-purple-400' : 'text-purple-500/60'}`} />
                  <span className="truncate flex-1 text-[11px]">{file.path}</span>
                </button>
              );
            })}
          </div>

          {/* Quick Setup Card */}
          <div className="p-2.5 rounded-xl bg-purple-950/30 border border-purple-500/20 text-[11px] space-y-1.5 text-purple-300">
            <div className="font-bold text-purple-200 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-purple-400" />
              <span>Android Studio Steps</span>
            </div>
            <ol className="list-decimal list-inside space-y-0.5 text-[10px] text-purple-300/80">
              <li>Open Android Studio (Koala/Ladybug)</li>
              <li>Click <b>Open</b> & select the extracted folder</li>
              <li>Let Gradle sync with JDK 17</li>
              <li>Press <b>Run (Shift + F10)</b></li>
            </ol>
          </div>
        </div>

        {/* Right: Code Viewer */}
        <div className="md:col-span-8 rounded-2xl bg-[#090616] border border-purple-500/30 flex flex-col overflow-hidden shadow-[inset_0_0_20px_rgba(0,0,0,0.8)]">
          {/* Code Viewer Header */}
          <div className="px-4 py-2.5 bg-[#120d2c] border-b border-purple-500/25 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
              <span className="font-mono text-xs font-semibold text-purple-200 ml-2">
                {currentFile.path}
              </span>
            </div>

            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-950/80 hover:bg-purple-900/60 border border-purple-500/40 text-xs font-semibold text-purple-200 transition"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-green-400" />
                  <span className="text-green-300">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-purple-400" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>

          {/* Syntax Highlighted Code Box */}
          <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-purple-100 selection:bg-purple-800">
            <pre className="whitespace-pre">
              <code>{currentFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
