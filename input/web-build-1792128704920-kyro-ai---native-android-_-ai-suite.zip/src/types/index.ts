export type FeatureTab = 'chat' | 'study' | 'writing' | 'code' | 'translator' | 'studio';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface StudyOptions {
  mode: 'quiz' | 'flashcards' | 'summarize' | 'explain';
  topic: string;
  level: string;
}

export interface WritingOptions {
  action: 'essay' | 'tone' | 'grammar' | 'paraphrase';
  content: string;
  tone: string;
  targetLength: string;
}

export interface CodeOptions {
  action: 'generate' | 'debug' | 'refactor' | 'explain';
  codeOrPrompt: string;
  language: string;
}

export interface TranslateOptions {
  text: string;
  sourceLang: string;
  targetLang: string;
  formality: string;
}

export interface StudioOptions {
  systemPrompt: string;
  userPrompt: string;
  temperature: number;
  jsonMode: boolean;
}
