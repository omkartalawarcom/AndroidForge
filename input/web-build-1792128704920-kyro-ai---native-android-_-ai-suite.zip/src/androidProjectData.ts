export interface AndroidFile {
  path: string;
  name: string;
  language: 'kotlin' | 'xml' | 'groovy' | 'toml' | 'markdown' | 'properties';
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidFile[] = [
  {
    path: 'app/src/main/java/com/kyro/ai/MainActivity.kt',
    name: 'MainActivity.kt',
    language: 'kotlin',
    content: `package com.kyro.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.kyro.ai.ui.components.KyroBottomBar
import com.kyro.ai.ui.components.KyroHeader
import com.kyro.ai.ui.navigation.Screen
import com.kyro.ai.ui.screens.chat.ChatScreen
import com.kyro.ai.ui.screens.code.CodeScreen
import com.kyro.ai.ui.screens.study.StudyScreen
import com.kyro.ai.ui.screens.studio.StudioScreen
import com.kyro.ai.ui.screens.translator.TranslatorScreen
import com.kyro.ai.ui.screens.writing.WritingScreen
import com.kyro.ai.ui.theme.DarkBackground
import com.kyro.ai.ui.theme.KyroAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KyroAppTheme {
                KyroMainScreen()
            }
        }
    }
}

@Composable
fun KyroMainScreen() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Chat) }

    Scaffold(
        topBar = {
            KyroHeader(
                title = "KYRO AI",
                subtitle = currentScreen.title
            )
        },
        bottomBar = {
            KyroBottomBar(
                currentRoute = currentScreen.route,
                onNavigate = { currentScreen = it }
            )
        },
        containerColor = DarkBackground
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DarkBackground)
        ) {
            when (currentScreen) {
                is Screen.Chat -> ChatScreen()
                is Screen.Study -> StudyScreen()
                is Screen.Writing -> WritingScreen()
                is Screen.Code -> CodeScreen()
                is Screen.Translator -> TranslatorScreen()
                is Screen.Studio -> StudioScreen()
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/kyro/ai/ui/theme/Color.kt',
    name: 'Color.kt',
    language: 'kotlin',
    content: `package com.kyro.ai.ui.theme

import androidx.compose.ui.graphics.Color

// KYRO AI Premium Purple Neon Palette
val NeonPurplePrimary = Color(0xFFA855F7)
val NeonPurpleLight = Color(0xFFC084FC)
val NeonPurpleDark = Color(0xFF7E22CE)
val NeonPinkAccent = Color(0xFFEC4899)
val NeonCyanAccent = Color(0xFF06B6D4)
val NeonGlow = Color(0xFFD946EF)

// Dark obsidian background & surfaces
val DarkBackground = Color(0xFF0B0816)
val DarkSurface = Color(0xFF130E26)
val DarkSurfaceVariant = Color(0xFF1E163B)
val DarkCardBackground = Color(0xFF181230)
val DarkBorder = Color(0xFF382361)

// Text & Content Colors
val TextPrimary = Color(0xFFF3E8FF)
val TextSecondary = Color(0xFFC4B5FD)
val TextMuted = Color(0xFF9381BF)
val TextHighlight = Color(0xFFE9D5FF)

val StatusSuccess = Color(0xFF10B981)
val StatusError = Color(0xFFEF4444)`
  },
  {
    path: 'app/src/main/java/com/kyro/ai/ui/theme/Theme.kt',
    name: 'Theme.kt',
    language: 'kotlin',
    content: `package com.kyro.ai.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val KyroDarkColorScheme = darkColorScheme(
    primary = NeonPurplePrimary,
    onPrimary = DarkBackground,
    primaryContainer = DarkSurfaceVariant,
    onPrimaryContainer = NeonPurpleLight,
    secondary = NeonPinkAccent,
    onSecondary = DarkBackground,
    tertiary = NeonCyanAccent,
    onTertiary = DarkBackground,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    outlineVariant = NeonPurpleDark
)

@Composable
fun KyroAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = KyroDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = DarkBackground.toArgb()
            window.navigationBarColor = DarkBackground.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = KyroTypography,
        content = content
    )
}`
  },
  {
    path: 'app/src/main/java/com/kyro/ai/ui/screens/chat/ChatScreen.kt',
    name: 'ChatScreen.kt',
    language: 'kotlin',
    content: `package com.kyro.ai.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyro.ai.data.model.ChatMessage
import com.kyro.ai.data.model.ChatMessagePayload
import com.kyro.ai.data.repository.KyroRepository
import com.kyro.ai.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    repository: KyroRepository = remember { KyroRepository() }
) {
    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                role = "model",
                text = "Hello! I am KYRO AI. How can I assist your workflow, calculations, or inquiries today?"
            )
        )
    }

    fun sendMessage(text: String) {
        if (text.isBlank() || isLoading) return
        val userMsg = ChatMessage(role = "user", text = text)
        messages.add(userMsg)
        inputText = ""
        isLoading = true

        scope.launch {
            listState.animateScrollToItem(messages.size - 1)
            val history = messages.map { ChatMessagePayload(it.role, it.text) }
            val result = repository.chat(history)
            result.onSuccess { reply ->
                messages.add(ChatMessage(role = "model", text = reply))
            }.onFailure { err ->
                messages.add(ChatMessage(role = "model", text = "Error: " + err.localizedMessage))
            }
            isLoading = false
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 280.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isUser) Brush.horizontalGradient(listOf(NeonPurpleDark, NeonPurplePrimary))
                                else Brush.horizontalGradient(listOf(DarkSurfaceVariant, DarkCardBackground))
                            )
                            .border(1.dp, if (isUser) NeonPurpleLight.copy(alpha = 0.5f) else DarkBorder, RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(text = msg.text, color = if (isUser) Color.White else TextPrimary, fontSize = 14.sp)
                    }
                }
            }
        }

        // Input
        Surface(color = DarkSurface, modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Ask KYRO AI...", color = TextMuted) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = { sendMessage(inputText) }) {
                    Icon(imageVector = Icons.Default.ArrowUpward, contentDescription = "Send", tint = NeonPurpleLight)
                }
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/kyro/ai/data/api/KyroApiService.kt',
    name: 'KyroApiService.kt',
    language: 'kotlin',
    content: `package com.kyro.ai.data.api

import com.kyro.ai.data.model.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface KyroApiService {
    @POST("api/ai/chat")
    suspend fun sendChatMessage(@Body request: ChatRequest): ChatResponse

    @POST("api/ai/study")
    suspend fun getStudyAssistance(@Body request: StudyRequest): StudyResponse

    @POST("api/ai/writing")
    suspend fun getWritingAssistance(@Body request: WritingRequest): WritingResponse

    @POST("api/ai/code")
    suspend fun getCodeAssistance(@Body request: CodeRequest): CodeResponse

    @POST("api/ai/translate")
    suspend fun translateText(@Body request: TranslateRequest): TranslateResponse

    @POST("api/ai/studio")
    suspend fun executeStudioPrompt(@Body request: StudioRequest): StudioResponse
}

object ApiClient {
    private var baseUrl: String = "https://your-kyro-backend.run.app/"

    fun setBaseUrl(newUrl: String) {
        baseUrl = if (newUrl.endsWith("/")) newUrl else "$newUrl/"
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    val apiService: KyroApiService by lazy {
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(KyroApiService::class.java)
    }
}`
  },
  {
    path: 'app/build.gradle.kts',
    name: 'app/build.gradle.kts',
    language: 'kotlin',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.kyro.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kyro.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.navigation.compose)

    implementation(libs.retrofit)
    implementation(libs.retrofit.converter.gson)
    implementation(libs.okhttp.logging)
    implementation(libs.kotlinx.coroutines.android)
}`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <application
        android:name=".KyroApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.KyroAI">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.KyroAI"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>`
  },
  {
    path: 'settings.gradle.kts',
    name: 'settings.gradle.kts',
    language: 'kotlin',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "KYRO AI"
include(":app")`
  },
  {
    path: 'gradle/libs.versions.toml',
    name: 'libs.versions.toml',
    language: 'toml',
    content: `[versions]
agp = "8.7.3"
kotlin = "2.0.21"
coreKtx = "1.15.0"
lifecycleRuntimeKtx = "2.8.7"
activityCompose = "1.9.3"
composeBom = "2024.12.01"
navigationCompose = "2.8.5"
retrofit = "2.11.0"
okhttp = "4.12.0"
coroutines = "1.9.0"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntimeKtx" }
androidx-lifecycle-viewmodel-compose = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-compose", version.ref = "lifecycleRuntimeKtx" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-navigation-compose = { group = "androidx.navigation", name = "navigation-compose", version.ref = "navigationCompose" }
retrofit = { group = "com.squareup.retrofit2", name = "retrofit", version.ref = "retrofit" }
retrofit-converter-gson = { group = "com.squareup.retrofit2", name = "converter-gson", version.ref = "retrofit" }
okhttp-logging = { group = "com.squareup.okhttp3", name = "logging-interceptor", version.ref = "okhttp" }
kotlinx-coroutines-android = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-android", version.ref = "coroutines" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }`
  },
  {
    path: 'README.md',
    name: 'README.md',
    language: 'markdown',
    content: `# KYRO AI - Native Android Application

Native Android app built with **Kotlin** and **Jetpack Compose** featuring a **premium purple neon theme**, matching the KYRO AI aesthetic.

### Features
1. **AI Chat**
2. **Study Assistant**
3. **Writing Assistant**
4. **Code Assistant**
5. **Translator**
6. **AI Studio**

### Zero Client-Side Secret Exposure
The Android app communicates with your server-side API proxy, ensuring the Gemini API key is never bundled in the APK.`
  }
];
