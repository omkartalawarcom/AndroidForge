import React, { useState } from 'react';
import {
  Smartphone,
  LayoutDashboard,
  Code2,
  Download,
  Sparkles,
  ShieldCheck,
  MessageSquare,
  GraduationCap,
  PenTool,
  Languages,
  Sliders,
  ExternalLink
} from 'lucide-react';
import { AndroidDeviceFrame } from './components/AndroidDeviceFrame';
import { AndroidCodeExplorer } from './components/AndroidCodeExplorer';
import { WebDashboard } from './components/WebDashboard';
import { FeatureTab } from './types';

type ViewMode = 'simulator' | 'web' | 'code';

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('simulator');
  const [selectedMobileTab, setSelectedMobileTab] = useState<FeatureTab>('chat');
  const [initialCodePath, setInitialCodePath] = useState<string | undefined>();

  const handleOpenSourceFromSimulator = (path?: string) => {
    if (path) setInitialCodePath(path);
    setViewMode('code');
  };

  const handleSwitchToMobileFromWeb = (tab: FeatureTab) => {
    setSelectedMobileTab(tab);
    setViewMode('simulator');
  };

  return (
    <div className="min-h-screen bg-[#070510] text-purple-100 flex flex-col font-sans">
      {/* Top Main Navigation Bar */}
      <header className="sticky top-0 z-50 bg-[#0e0921]/90 backdrop-blur-xl border-b border-purple-500/20 px-4 lg:px-8 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Logo & Platform Info */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 via-fuchsia-600 to-purple-500 flex items-center justify-center font-black text-white text-lg shadow-[0_0_15px_rgba(168,85,247,0.5)]">
              K
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-lg tracking-wider text-white">KYRO</span>
                <span className="font-extrabold text-lg text-purple-400">AI</span>
                <span className="hidden sm:inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-950/80 border border-purple-500/40 text-purple-300">
                  ANDROID & WEB
                </span>
              </div>
              <p className="hidden md:block text-[11px] text-purple-300/60">
                Native Jetpack Compose Application & Full-Stack AI Suite
              </p>
            </div>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex items-center bg-[#150f2e] p-1 rounded-xl border border-purple-500/30 shadow-inner">
            <button
              onClick={() => setViewMode('simulator')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                viewMode === 'simulator'
                  ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                  : 'text-purple-300 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Android App</span>
            </button>

            <button
              onClick={() => setViewMode('web')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                viewMode === 'web'
                  ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                  : 'text-purple-300 hover:text-white'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>Web Suite</span>
            </button>

            <button
              onClick={() => setViewMode('code')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                viewMode === 'code'
                  ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                  : 'text-purple-300 hover:text-white'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Kotlin & Gradle</span>
            </button>
          </div>

          {/* Right Status */}
          <div className="hidden lg:flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-purple-300/80">
              <ShieldCheck className="w-4 h-4 text-green-400" />
              <span>API Key Protected</span>
            </div>
            <button
              onClick={() => setViewMode('code')}
              className="px-3 py-1.5 rounded-lg bg-purple-950/80 border border-purple-500/40 text-xs font-semibold text-purple-200 hover:border-purple-400 transition flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-purple-400" />
              <span>Export APK/Zip</span>
            </button>
          </div>
        </div>
      </header>

      {/* Feature Quick Switcher when on Simulator */}
      {viewMode === 'simulator' && (
        <div className="bg-[#0b0819] border-b border-purple-500/15 py-2 px-4 overflow-x-auto">
          <div className="max-w-4xl mx-auto flex items-center justify-center gap-1 sm:gap-2">
            {[
              { id: 'chat' as FeatureTab, label: '1. AI Chat', icon: MessageSquare },
              { id: 'study' as FeatureTab, label: '2. Study Assistant', icon: GraduationCap },
              { id: 'writing' as FeatureTab, label: '3. Writing Assistant', icon: PenTool },
              { id: 'code' as FeatureTab, label: '4. Code Assistant', icon: Code2 },
              { id: 'translator' as FeatureTab, label: '5. Translator', icon: Languages },
              { id: 'studio' as FeatureTab, label: '6. AI Studio', icon: Sliders }
            ].map(f => {
              const Icon = f.icon;
              const isSel = selectedMobileTab === f.id;
              return (
                <button
                  key={f.id}
                  onClick={() => setSelectedMobileTab(f.id)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                    isSel
                      ? 'bg-purple-600/40 border border-purple-400 text-purple-200 shadow-[0_0_10px_rgba(168,85,247,0.3)]'
                      : 'text-purple-400/70 hover:text-purple-200 hover:bg-purple-950/40'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{f.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col items-center">
        {viewMode === 'simulator' && (
          <div className="w-full flex flex-col items-center">
            <AndroidDeviceFrame
              initialTab={selectedMobileTab}
              onOpenSourceCode={handleOpenSourceFromSimulator}
            />
          </div>
        )}

        {viewMode === 'web' && (
          <div className="w-full">
            <WebDashboard
              onSwitchToMobile={handleSwitchToMobileFromWeb}
              onOpenCodeExplorer={() => setViewMode('code')}
            />
          </div>
        )}

        {viewMode === 'code' && (
          <div className="w-full">
            <AndroidCodeExplorer selectedFileInitial={initialCodePath} />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-purple-500/20 bg-[#0a0715] px-4 py-4 text-center text-xs text-purple-400/60">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>KYRO AI · Native Android Application (Kotlin / Jetpack Compose) & Web Suite</span>
          <span className="font-mono text-[11px] text-purple-400/80">
            Secure Backend Gemini 3.8 Flash Engine · SDK 35 Compatible
          </span>
        </div>
      </footer>
    </div>
  );
}
