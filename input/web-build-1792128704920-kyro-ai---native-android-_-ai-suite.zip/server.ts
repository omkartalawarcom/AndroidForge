import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize secure server-side Gemini client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper for safe Gemini calls with automatic fallback for regional spikes
async function callGemini(contents: any, systemInstruction?: string, temperature = 0.7) {
  const modelsToTry = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];
  let lastError: any = null;

  for (const model of modelsToTry) {
    try {
      const config: any = {
        temperature,
      };
      if (systemInstruction) {
        config.systemInstruction = systemInstruction;
      }

      const response = await ai.models.generateContent({
        model,
        contents,
        config,
      });

      if (response && response.text) {
        return response.text;
      }
    } catch (error: any) {
      console.warn(`Model ${model} failed, attempting next model:`, error?.message || error);
      lastError = error;
    }
  }

  throw new Error(lastError?.message || 'Error communicating with AI service. Please retry in a moment.');
}

// 1. AI Chat Endpoint
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { messages, systemInstruction } = req.body;
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    // Convert messages to Gemini format
    const contents = messages.map((m: { role: string; text: string }) => ({
      role: m.role === 'model' || m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.text }],
    }));

    const defaultSystem =
      'You are KYRO AI, a futuristic and highly intelligent purple-neon themed personal AI assistant. You are concise, insightful, polite, and exceptionally capable across technical, creative, and analytical tasks.';

    const reply = await callGemini(contents, systemInstruction || defaultSystem, 0.7);
    return res.json({ reply });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 2. Study Assistant Endpoint
app.post('/api/ai/study', async (req: Request, res: Response) => {
  try {
    const { mode, topic, level } = req.body;
    if (!topic) {
      return res.status(400).json({ error: 'Topic is required' });
    }

    let prompt = '';
    let systemInstruction = 'You are KYRO Study Assistant, specialized in accelerated learning, active recall, and pedagogical clarity.';

    switch (mode) {
      case 'quiz':
        prompt = `Generate a 4-question interactive multiple-choice quiz about "${topic}" (Audience level: ${level || 'Intermediate'}). Format with questions, 4 labeled options (A, B, C, D), correct answer explanation, and key takeaway.`;
        break;
      case 'flashcards':
        prompt = `Create 5 high-yield flashcards for studying "${topic}". For each card provide:
Card [Number]:
Front: [Key concept / question]
Back: [Clear, memorable explanation or formula]`;
        break;
      case 'summarize':
        prompt = `Provide a structured, easy-to-digest study summary of "${topic}". Include:
1. Core Concept Overview
2. Top 3-5 Critical Principles
3. Common Misconceptions
4. Quick Review Formula / Mnemonics`;
        break;
      case 'explain':
      default:
        prompt = `Explain the following topic thoroughly yet simply as if preparing a student for an exam: "${topic}". Use real-world analogies, step-by-step logic, and bullet points.`;
        break;
    }

    const reply = await callGemini(prompt, systemInstruction, 0.5);
    return res.json({ reply });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 3. Writing Assistant Endpoint
app.post('/api/ai/writing', async (req: Request, res: Response) => {
  try {
    const { action, content, tone, targetLength } = req.body;
    if (!content) {
      return res.status(400).json({ error: 'Content is required' });
    }

    let prompt = '';
    const systemInstruction = 'You are KYRO Writing Assistant, an elite editor and copywriter skilled in rhetoric, narrative pacing, and tonal precision.';

    switch (action) {
      case 'essay':
        prompt = `Draft an eloquent, well-structured composition based on: "${content}". Tone: ${tone || 'Academic & Persuasive'}. Desired length: ${targetLength || 'Medium'}. Include an engaging introduction, structured body paragraphs, and strong conclusion.`;
        break;
      case 'tone':
        prompt = `Rewrite the following text into a ${tone || 'Professional & Confident'} tone while preserving all original core facts:
"${content}"`;
        break;
      case 'grammar':
        prompt = `Proofread and polish the following text. Fix all grammatical, punctuation, and structural flaws. Provide:
1. Polished Version
2. Summary of key enhancements made:
"${content}"`;
        break;
      case 'paraphrase':
      default:
        prompt = `Paraphrase the following text in 3 distinct variations (1. Punchy & Concise, 2. Sophisticated & Formal, 3. Engaging & Casual):
"${content}"`;
        break;
    }

    const reply = await callGemini(prompt, systemInstruction, 0.7);
    return res.json({ reply });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 4. Code Assistant Endpoint
app.post('/api/ai/code', async (req: Request, res: Response) => {
  try {
    const { action, codeOrPrompt, language } = req.body;
    if (!codeOrPrompt) {
      return res.status(400).json({ error: 'Code or prompt is required' });
    }

    const lang = language || 'Kotlin';
    const systemInstruction = `You are KYRO Code Assistant, an expert principal software engineer specializing in ${lang}, modern architectures, Android Jetpack Compose, clean code, and algorithms. Always provide clean, idiomatic code with brief explanations.`;

    let prompt = '';
    switch (action) {
      case 'generate':
        prompt = `Write production-ready, clean, well-commented ${lang} code for the following specification:\n${codeOrPrompt}`;
        break;
      case 'debug':
        prompt = `Identify any bugs, memory leaks, performance issues, or edge cases in this ${lang} snippet and provide the corrected code:\n${codeOrPrompt}`;
        break;
      case 'refactor':
        prompt = `Refactor this ${lang} code for peak readability, modern idioms, best practices, and maintainability:\n${codeOrPrompt}`;
        break;
      case 'explain':
      default:
        prompt = `Explain step-by-step how this ${lang} code works, its algorithmic time/space complexity, and architecture:\n${codeOrPrompt}`;
        break;
    }

    const reply = await callGemini(prompt, systemInstruction, 0.2);
    return res.json({ reply });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 5. Translator Endpoint
app.post('/api/ai/translate', async (req: Request, res: Response) => {
  try {
    const { text, sourceLang, targetLang, formality } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text to translate is required' });
    }

    const systemInstruction = 'You are KYRO Translator, a master linguistic AI specializing in contextual accuracy, cultural nuances, and idiomatic phrasing.';
    const prompt = `Translate the following text from ${sourceLang || 'Auto-detect'} to ${targetLang || 'Spanish'}.
Formality: ${formality || 'Natural/Standard'}.

Original Text:
"${text}"

Provide the response in the following format:
- Translated Text
- Phonetic Pronunciation (IPA or romanized)
- Cultural / Nuance Notes (brief)
- Alternative Contextual Phrasings (if relevant)`;

    const reply = await callGemini(prompt, systemInstruction, 0.3);
    return res.json({ reply });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 6. AI Studio Playground Endpoint
app.post('/api/ai/studio', async (req: Request, res: Response) => {
  try {
    const { systemPrompt, userPrompt, temperature, jsonMode } = req.body;
    if (!userPrompt) {
      return res.status(400).json({ error: 'User prompt is required' });
    }

    const config: any = {
      temperature: typeof temperature === 'number' ? temperature : 0.7,
    };
    if (systemPrompt) {
      config.systemInstruction = systemPrompt;
    }
    if (jsonMode) {
      config.responseMimeType = 'application/json';
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config,
    });

    return res.json({
      reply: response.text || '',
      model: 'gemini-3.8-flash',
      usage: response.usageMetadata,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'online',
    app: 'KYRO AI',
    version: '1.0.0',
    platform: 'Android & Web Native Suite',
  });
});

// Setup Vite or static serving
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 KYRO AI Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
